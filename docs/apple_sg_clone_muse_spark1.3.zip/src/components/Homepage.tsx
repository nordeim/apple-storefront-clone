import { useEffect, useRef, useState } from "react";
import { ChevronLeft, ChevronRight, Play, Plus, Check } from "lucide-react";
import { PRODUCTS, ENTERTAINMENT, SGD, ACCESSORIES } from "../data/catalog";
import { useShop } from "../lib/shop";
import { cn } from "../utils/cn";

function useReveal() {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const els = ref.current?.querySelectorAll(".reveal") ?? [];
    const io = new IntersectionObserver(
      (entries) => entries.forEach((e) => e.isIntersecting && e.target.classList.add("is-visible")),
      { threshold: 0.12 }
    );
    els.forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, []);
  return ref;
}

/* Stylised device renders — pure CSS/SVG, no external assets */
function IPhoneDuoVisual() {
  return (
    <div className="relative mx-auto flex h-[300px] items-center justify-center sm:h-[380px]" aria-hidden="true">
      <div className="absolute h-[260px] w-[260px] rounded-full bg-[#2b3a8f]/30 blur-[90px] animate-pulse-glow sm:h-[340px] sm:w-[420px]" />
      {/* closed phone */}
      <div className="animate-floaty relative z-10 h-[230px] w-[112px] rounded-[28px] border border-white/25 bg-gradient-to-b from-[#1c2340] to-black p-[6px] shadow-[0_30px_80px_rgba(0,0,0,0.6)] sm:h-[300px] sm:w-[145px]" style={{ ["--tilt" as string]: "-8deg" }}>
        <div className="flex h-full flex-col overflow-hidden rounded-[22px] bg-gradient-to-b from-[#3b82f6] via-[#1e1b4b] to-black">
          <div className="mx-auto mt-2 h-5 w-16 rounded-full bg-black/80" />
          <div className="grid flex-1 grid-cols-4 gap-1.5 p-3 pt-4">
            {Array.from({ length: 16 }).map((_, i) => (
              <div key={i} className="aspect-square rounded-[7px] bg-white/25 backdrop-blur" style={{ opacity: 0.35 + (i % 5) * 0.14 }} />
            ))}
          </div>
        </div>
      </div>
      {/* open foldable */}
      <div className="animate-floaty relative z-20 -ml-8 h-[240px] w-[200px] rounded-[18px] border border-white/25 bg-[#0b1026] p-[6px] shadow-[0_30px_90px_rgba(59,130,246,0.45)] sm:h-[320px] sm:w-[260px]" style={{ ["--tilt" as string]: "7deg", animationDelay: "0.8s" }}>
        <div className="relative flex h-full overflow-hidden rounded-[13px] bg-gradient-to-br from-[#172554] via-[#1d4ed8] to-[#7dd3fc]">
          <div className="absolute left-1/2 top-0 h-full w-px bg-white/25" />
          <div className="flex flex-1 flex-col justify-end p-4">
            <p className="text-[10px] uppercase tracking-widest text-white/70">7.8″ Inner display</p>
            <div className="mt-2 flex gap-1.5">
              <div className="h-8 flex-1 rounded-lg bg-white/25" />
              <div className="h-8 flex-1 rounded-lg bg-white/15" />
              <div className="h-8 flex-1 rounded-lg bg-white/30" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function IPhoneProVisual() {
  return (
    <div className="relative mx-auto flex h-[280px] items-end justify-center gap-6 sm:h-[360px]" aria-hidden="true">
      <div className="absolute bottom-0 h-[180px] w-[420px] rounded-[100%] bg-[#ff2d78]/20 blur-[80px] animate-pulse-glow" />
      <p className="text-glow-pro pointer-events-none absolute top-2 select-none text-[64px] font-black tracking-tighter sm:text-[120px]" aria-hidden="true">Pro</p>
      {[0, 1].map((i) => (
        <div
          key={i}
          className={cn("animate-floaty relative rounded-[34px] bg-gradient-to-b p-[7px] shadow-[0_36px_90px_rgba(0,0,0,0.65)]", i === 0 ? "h-[230px] w-[112px] sm:h-[300px] sm:w-[148px] from-[#8a7f72] via-[#5e1a2a] to-[#1a0a10]" : "hidden h-[240px] w-[118px] sm:block sm:h-[315px] sm:w-[155px] from-[#3c3c3d] via-[#1d1d1f] to-black")}
          style={{ ["--tilt" as string]: i === 0 ? "-6deg" : "6deg", animationDelay: `${i * 0.9}s` }}
        >
          {i === 0 ? (
            <div className="flex h-full flex-col rounded-[27px] bg-gradient-to-b from-[#6d1f33] to-[#1a0a10] p-2.5">
              <div className="grid grid-cols-2 gap-1.5">
                <div className="col-span-2 flex h-14 items-center justify-center rounded-2xl bg-black/40">
                  <div className="flex gap-1.5">
                    <span className="h-6 w-6 rounded-full bg-[#1d1d1f] ring-2 ring-white/20" />
                    <span className="h-6 w-6 rounded-full bg-[#1d1d1f] ring-2 ring-white/20" />
                    <span className="h-6 w-6 rounded-full bg-[#1d1d1f] ring-2 ring-white/20" />
                  </div>
                </div>
              </div>
              <div className="mx-auto mt-6 h-10 w-10 rounded-full bg-white/10 backdrop-blur flex items-center justify-center">
                <svg viewBox="0 0 384 512" className="h-5 w-4 text-white/60" fill="currentColor"><path d="M318.7 268.7c-.2-36.7 16.4-64.4 50-84.8-18.8-26.9-47.2-41.7-84.7-44.6-35.5-2.8-74.3 20.7-88.5 20.7-15 0-49.4-19.7-76.4-19.7C63.3 141.2 4 184.8 4 273.5q0 39.3 14.4 81.2c12.8 36.7 59 126.7 107.2 125.2 25.2-.6 43-17.9 75.8-17.9 31.8 0 48.3 17.9 76.4 17.9 48.6-.7 90.4-82.5 102.6-119.3-65.2-30.7-61.7-90-61.7-91.9zm-56.6-164.2c27.3-32.4 24.8-61.9 24-72.5-24.1 1.4-52 16.4-67.9 34.9-17.5 19.8-27.8 44.3-25.6 71.9 26.1 2 49.9-11.4 69.5-34.3z" /></svg>
              </div>
            </div>
          ) : (
            <div className="flex h-full flex-col overflow-hidden rounded-[27px] bg-black">
              <div className="mx-auto mt-2 h-5 w-20 rounded-full bg-[#1d1d1f]" />
              <p className="mt-6 text-center text-[11px] text-white/80">9:41</p>
              <div className="mx-2 mt-2 flex-1 rounded-2xl bg-gradient-to-b from-[#ff9ecf]/40 via-[#7c3aed]/30 to-transparent" />
            </div>
          )}
        </div>
      ))}
    </div>
  );
}

function PromoVisual({ id }: { id: string }) {
  if (id === "homeview")
    return (
      <div className="flex items-end justify-center gap-3 pt-6" aria-hidden="true">
        {["#f5f5f7", "#fdba74", "#7dd3fc"].map((c, i) => (
          <div key={c} className="animate-floaty rounded-2xl border border-black/10 bg-white p-1.5 shadow-xl" style={{ animationDelay: `${i * 0.5}s`, ["--tilt" as string]: `${(i - 1) * 4}deg` }}>
            <div className="flex h-24 w-20 flex-col rounded-xl p-1.5 sm:h-28 sm:w-24" style={{ background: `linear-gradient(135deg, ${c}, #fff)` }}>
              <div className="h-1.5 w-8 rounded-full bg-black/15" />
              <div className="mt-2 grid grid-cols-2 gap-1">
                <span className="h-6 rounded-md bg-black/10" /><span className="h-6 rounded-md bg-black/10" />
                <span className="h-6 rounded-md bg-black/20" /><span className="h-6 rounded-md bg-black/10" />
              </div>
            </div>
            <div className="mx-auto mt-1.5 h-3 w-10 rounded-full bg-black/10" />
          </div>
        ))}
      </div>
    );
  if (id === "ipad-a16")
    return (
      <div className="flex items-center justify-center gap-2 pt-6" aria-hidden="true">
        <div className="h-36 w-28 rotate-[-6deg] rounded-2xl bg-[#1d1d1f] p-1 shadow-2xl sm:h-44 sm:w-36">
          <div className="flex h-full flex-col rounded-xl bg-gradient-to-br from-[#f472b6] via-[#a5b4fc] to-[#7dd3fc] p-2">
            <div className="grid grid-cols-3 gap-1">{Array.from({ length: 9 }).map((_, i) => <span key={i} className="h-6 rounded-md bg-white/30" />)}</div>
          </div>
        </div>
        <div className="flex flex-col gap-1.5">
          {["#5b8fd4", "#efa9c6", "#f0d060", "#e3e4e6"].map((c) => <span key={c} className="h-5 w-5 rounded-full ring-2 ring-white shadow" style={{ background: c }} />)}
        </div>
      </div>
    );
  if (id === "watch-s12")
    return (
      <div className="flex items-center justify-center gap-4 pt-4" aria-hidden="true">
        {[0, 1].map((i) => (
          <div key={i} className={cn("animate-floaty flex flex-col items-center", i === 1 && "scale-90 opacity-90")} style={{ animationDelay: `${i}s` }}>
            <div className="h-10 w-8 rounded-t-xl bg-[#4d5b2f]" />
            <div className="flex h-32 w-24 items-center justify-center rounded-[28px] bg-[#1d1d1f] p-1.5 shadow-2xl">
              <div className="flex h-full w-full flex-col items-center justify-center rounded-[22px] bg-black text-white">
                <span className="text-[10px] text-[#4ade80]">♥ 72</span>
                <svg viewBox="0 0 100 30" className="mt-1 h-6 w-16 text-[#4ade80]" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M0 15h18l4-8 6 16 5-12 4 6 3-2h60" /></svg>
                <span className="mt-1 text-[8px] text-white/50">ECG · HR</span>
              </div>
            </div>
            <div className="h-10 w-8 rounded-b-xl bg-[#4d5b2f]" />
          </div>
        ))}
      </div>
    );
  if (id === "airpods-pro-3")
    return (
      <div className="flex items-center justify-center gap-6 pt-6" aria-hidden="true">
        <div className="h-28 w-36 rounded-3xl bg-white shadow-2xl ring-1 ring-black/10 flex items-center justify-center gap-4">
          {[0, 1].map((i) => <div key={i} className="animate-floaty h-14 w-5 rounded-full bg-gradient-to-b from-white to-[#cbd5e1] shadow-lg ring-1 ring-black/10" style={{ animationDelay: `${i * 0.7}s` }} />)}
        </div>
      </div>
    );
  return (
    <div className="mx-auto mt-6 h-36 w-64 overflow-hidden rounded-t-2xl bg-[#0b0b0e] shadow-2xl ring-1 ring-white/15 sm:h-44 sm:w-80" aria-hidden="true">
      <div className="flex h-full flex-col items-center justify-center bg-[radial-gradient(ellipse_at_center,#312e81_0%,#000_70%)] p-4 text-center">
        <p className="text-glow-pro text-3xl font-black sm:text-4xl">Pro</p>
        <div className="mt-2 h-1.5 w-40 overflow-hidden rounded-full bg-white/15"><div className="h-full w-2/3 rounded-full bg-gradient-to-r from-[#7dd3fc] via-[#c084fc] to-[#f472b6]" /></div>
      </div>
      <div className="h-2 bg-[#1d1d1f]" />
    </div>
  );
}

export default function Homepage() {
  const { go, addToBag, wishlist, toggleWish } = useShop();
  const wrapRef = useReveal();
  const tvRef = useRef<HTMLDivElement>(null);
  const [tvIndex, setTvIndex] = useState(0);

  const promos = [
    { pid: "homeview", eyebrow: "Apple HomeView", title: "Designed for life at home.", cta: "Learn more", dark: false },
    { pid: "ipad-a16", eyebrow: "iPad", title: "Now with A16 and double the storage.", cta: "Buy", dark: false },
    { pid: "watch-s12", eyebrow: "Apple Watch Series 12", title: "The most accurate heart-rate sensing.", cta: "Buy", dark: true },
    { pid: "macbook-pro-14-m6", eyebrow: "MacBook Pro", title: "PROLED XDR Display.", cta: "Buy", dark: true },
    { pid: "macbook-pro-m6-side", eyebrow: "MacBook Pro 14″", title: "Now with M6.", cta: "Buy", dark: false },
    { pid: "airpods-pro-3", eyebrow: "AirPods Pro 3", title: "World's best in-ear ANC.", cta: "Buy", dark: false },
  ];

  const scrollTv = (dir: number) => {
    const el = tvRef.current;
    if (!el) return;
    const w = el.clientWidth * 0.8;
    el.scrollBy({ left: dir * w, behavior: "smooth" });
    setTvIndex((i) => Math.max(0, Math.min(ENTERTAINMENT.length - 1, i + dir)));
  };

  return (
    <div ref={wrapRef}>
      {/* HERO 1 — iPhone Duo */}
      <section className="relative overflow-hidden bg-black text-center text-white" aria-label="iPhone Duo">
        <div className="reveal mx-auto max-w-4xl px-5 pb-2 pt-14 sm:pt-20">
          <h1 className="display-hero">iPhone Duo</h1>
          <p className="mt-2 text-[21px] text-white/80 sm:text-[28px]">Hello, hello.</p>
          <div className="mt-5 flex items-center justify-center gap-3">
            <button onClick={() => go({ name: "product", id: "iphone-duo" })} className="btn-apple-blue px-6 py-2.5 text-[15px]">Buy</button>
            <button onClick={() => go({ name: "product", id: "iphone-duo" })} className="apple-link text-[15px]">Learn more ›</button>
          </div>
        </div>
        <div className="reveal reveal-delay-1 px-5 pb-10"><IPhoneDuoVisual /></div>
        <p className="pb-6 text-[12px] text-white/40">Foldable 7.8″ inner display · From {SGD(2499)} or S$104.08/mo. for 24 mo. before trade-in</p>
      </section>

      {/* HERO 2 — 18 Pro */}
      <section className="relative overflow-hidden bg-[#0a0a0c] pb-10 pt-14 text-center text-white sm:pt-20" aria-label="iPhone 18 Pro">
        <div className="reveal mx-auto max-w-4xl px-5">
          <h2 className="display-hero">iPhone 18 Pro</h2>
          <p className="mt-2 bg-gradient-to-r from-[#9fb4ff] via-white to-[#ff9ecf] bg-clip-text text-[21px] text-transparent sm:text-[28px]">Pro further.</p>
          <div className="mt-5 flex items-center justify-center gap-3">
            <button onClick={() => go({ name: "product", id: "iphone-18-pro" })} className="btn-apple-blue px-6 py-2.5 text-[15px]">Buy</button>
            <button onClick={() => go({ name: "compare" })} className="apple-link text-[15px]">Compare models ›</button>
          </div>
        </div>
        <div className="reveal reveal-delay-1 mt-4 px-5"><IPhoneProVisual /></div>
      </section>

      {/* Holiday strip */}
      <section className="bg-[#fbfbfd] px-5 py-12 text-center" aria-label="Holiday gifts">
        <div className="reveal mx-auto max-w-3xl">
          <p className="text-[14px] font-semibold uppercase tracking-[0.2em] text-[#b00020]">Holiday 2026</p>
          <h2 className="display-section mt-2">Gifts they’ll love.</h2>
          <p className="mt-2 text-[17px] text-[#6e6e73]">Find their perfect match. Engrave it for free. Deliver it in time.</p>
          <div className="mt-5 flex flex-wrap items-center justify-center gap-3">
            <button onClick={() => go({ name: "store" })} className="btn-apple-blue px-6 py-2.5 text-[15px]">Shop gifts</button>
            <button onClick={() => go({ name: "tradein" })} className="btn-apple-outline px-6 py-2.5 text-[15px]">Estimate Trade In</button>
          </div>
          <div className="animate-marquee mt-8 flex gap-3 overflow-hidden [mask-image:linear-gradient(to_right,transparent,black_8%,black_92%,transparent)]" aria-hidden="true">
            {[0, 1].map((k) => (
              <div key={k} className="flex shrink-0 gap-3 pr-3">
                {ACCESSORIES.slice(0, 6).map((a) => (
                  <span key={`${k}-${a.id}`} className="whitespace-nowrap rounded-full bg-white px-4 py-2 text-[13px] shadow-sm ring-1 ring-black/5">{a.name} · {SGD(a.price)}</span>
                ))}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Promo grid — 2 col like apple.com */}
      <section className="grid grid-cols-1 gap-3 bg-[#fbfbfd] px-3 pb-3 md:grid-cols-2" aria-label="Featured products">
        {promos.map((pr, i) => {
          const p = PRODUCTS.find((x) => x.id === pr.pid)!;
          const saved = wishlist.includes(p.id);
          return (
            <article key={pr.pid + i} className={cn("reveal lift relative flex min-h-[540px] flex-col overflow-hidden rounded-2xl px-6 pt-10 text-center sm:min-h-[580px]", pr.dark ? "bg-black text-white" : "bg-white text-[#1d1d1f] shadow-sm")} style={{ transitionDelay: `${(i % 2) * 0.08}s` }}>
              <button
                aria-label={saved ? `Unsave ${p.name}` : `Save ${p.name}`}
                onClick={() => toggleWish(p.id)}
                className={cn("absolute right-4 top-4 rounded-full p-2", pr.dark ? "bg-white/10 hover:bg-white/20" : "bg-black/5 hover:bg-black/10")}
              >
                {saved ? <Check className="h-4 w-4 text-[#0071e3]" /> : <Plus className="h-4 w-4" />}
              </button>
              <p className={cn("text-[13px] font-semibold uppercase tracking-wide", pr.dark ? "text-white/60" : "text-[#6e6e73]")}>{pr.eyebrow}</p>
              <h3 className="display-promo mx-auto mt-1 max-w-sm">{pr.title}</h3>
              <div className="mt-3 flex items-center justify-center gap-4 text-[14px]">
                <button onClick={() => go({ name: "product", id: p.id })} className="apple-link">Learn more ›</button>
                <button onClick={() => go({ name: "product", id: p.id })} className="apple-link">Buy ›</button>
              </div>
              <div className="flex flex-1 flex-col justify-end pb-6"><PromoVisual id={p.id} /></div>
            </article>
          );
        })}
      </section>

      {/* Entertainment carousel */}
      <section className="bg-white py-14" aria-label="Entertainment">
        <div className="reveal mx-auto flex max-w-[1200px] items-end justify-between px-5">
          <div>
            <h2 className="display-section">Store. Stream. <span className="text-[#6e6e73]">Play.</span></h2>
            <p className="mt-2 text-[17px] text-[#6e6e73]">Apple services on every device — from {SGD(9.98)}/mo.</p>
          </div>
          <div className="hidden gap-2 sm:flex">
            <button aria-label="Scroll left" onClick={() => scrollTv(-1)} className="rounded-full bg-black/5 p-3 hover:bg-black/10"><ChevronLeft className="h-5 w-5" /></button>
            <button aria-label="Scroll right" onClick={() => scrollTv(1)} className="rounded-full bg-black/5 p-3 hover:bg-black/10"><ChevronRight className="h-5 w-5" /></button>
          </div>
        </div>
        <div ref={tvRef} className="snap-row no-scrollbar mt-6 flex gap-4 overflow-x-auto px-5 pb-2" role="list">
          {ENTERTAINMENT.map((e) => (
            <article key={e.id} role="listitem" className={cn("group relative h-[380px] w-[82vw] max-w-[520px] shrink-0 overflow-hidden rounded-2xl bg-gradient-to-br p-7 text-white sm:w-[520px]", e.gradient)}>
              <div className="absolute inset-0 bg-[radial-gradient(circle_at_80%_20%,rgba(255,255,255,0.22),transparent_55%)]" aria-hidden="true" />
              <p className="text-[12px] uppercase tracking-[0.18em] text-white/60">{e.duration}</p>
              <h3 className="mt-1 text-[34px] font-bold tracking-tight">{e.title}</h3>
              <p className="mt-1 text-white/75">{e.subtitle}</p>
              <div className="absolute bottom-6 left-7 flex gap-3">
                <button onClick={() => go({ name: "entertainment" })} className="rounded-full bg-white px-5 py-2 text-[14px] font-medium text-black transition hover:scale-[1.03]">{e.cta}</button>
                <button aria-label={`Play ${e.title} trailer`} className="flex items-center gap-1.5 rounded-full bg-white/15 px-4 py-2 text-[14px] backdrop-blur hover:bg-white/25"><Play className="h-3.5 w-3.5" /> Trailer</button>
              </div>
              <button
                onClick={() => addToBag({ productId: e.id, name: e.title, variant: "Monthly plan", unitPrice: 9.98, imageGradient: e.gradient, meta: "First 3 months free" })}
                className="absolute bottom-6 right-6 rounded-full bg-white/15 p-3 backdrop-blur hover:bg-white/30"
                aria-label={`Subscribe to ${e.title}`}
              >
                <Plus className="h-4 w-4" />
              </button>
            </article>
          ))}
        </div>
        <div className="dot-nav mt-4 flex justify-center gap-2" aria-hidden="true">
          {ENTERTAINMENT.map((e, i) => (
            <button key={e.id} onClick={() => { tvRef.current?.scrollTo({ left: i * (tvRef.current.clientWidth * 0.8), behavior: "smooth" }); setTvIndex(i); }} aria-label={`Go to slide ${i + 1}`} className={cn("h-2 rounded-full", tvIndex === i ? "w-8 bg-[#1d1d1f]" : "w-2 bg-black/20")} />
          ))}
        </div>
      </section>

      {/* Why Apple SG strip */}
      <section className="border-t border-black/5 bg-[#f5f5f7] px-5 py-12" aria-label="Why buy from Apple Singapore">
        <div className="mx-auto grid max-w-[1024px] grid-cols-1 gap-6 text-center sm:grid-cols-3">
          {[
            { t: "Free delivery", d: "Islandwide in 1–2 days. Express pickup at Orchard, MBS & Jewel." },
            { t: "0% instalments", d: "12/24/36-month plans with DBS, UOB, OCBC & Atome." },
            { t: "Trade In + GST invoice", d: "Up to S$1,150 credit. Business GST invoices on every order." },
          ].map((f) => (
            <div key={f.t} className="reveal rounded-2xl bg-white p-6 shadow-sm">
              <p className="text-[17px] font-bold">{f.t}</p>
              <p className="mt-1 text-[14px] text-[#6e6e73]">{f.d}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
