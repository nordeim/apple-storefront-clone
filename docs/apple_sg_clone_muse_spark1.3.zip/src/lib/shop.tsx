import { createContext, useCallback, useContext, useMemo, useState, type ReactNode } from "react";
import { PRODUCTS, ACCESSORIES, SGD as fmtSGD, GST_RATE, type Product } from "../data/catalog";

export type View =
  | { name: "home" }
  | { name: "store" }
  | { name: "category"; family: string }
  | { name: "product"; id: string }
  | { name: "compare" }
  | { name: "tradein" }
  | { name: "entertainment" }
  | { name: "accessories" }
  | { name: "support" }
  | { name: "checkout" }
  | { name: "order-success"; orderId: string }
  | { name: "stores" };

export interface BagLine {
  key: string;
  productId: string;
  name: string;
  variant: string;
  unitPrice: number;
  qty: number;
  imageGradient: string;
  meta?: string;
}

export interface Toast {
  id: number;
  title: string;
  body?: string;
}

interface ShopState {
  view: View;
  go: (v: View) => void;
  bag: BagLine[];
  addToBag: (line: Omit<BagLine, "key" | "qty">, qty?: number) => void;
  updateQty: (key: string, qty: number) => void;
  removeLine: (key: string) => void;
  clearBag: () => void;
  bagCount: number;
  subtotal: number;
  gst: number;
  wishlist: string[];
  toggleWish: (id: string) => void;
  toasts: Toast[];
  pushToast: (t: Omit<Toast, "id">) => void;
  dismissToast: (id: number) => void;
  searchOpen: boolean;
  setSearchOpen: (v: boolean) => void;
  bagOpen: boolean;
  setBagOpen: (v: boolean) => void;
  eduPricing: boolean;
  setEduPricing: (v: boolean) => void;
  promo: string | null;
  applyPromo: (code: string) => boolean;
  lastOrder: { id: string; total: number; email: string } | null;
  placeOrder: (email: string) => string;
  findProduct: (id: string) => Product | undefined;
}

const ShopCtx = createContext<ShopState | null>(null);

let toastSeq = 1;

export function ShopProvider({ children }: { children: ReactNode }) {
  const [view, setView] = useState<View>({ name: "home" });
  const [bag, setBag] = useState<BagLine[]>([]);
  const [wishlist, setWishlist] = useState<string[]>([]);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [searchOpen, setSearchOpen] = useState(false);
  const [bagOpen, setBagOpen] = useState(false);
  const [eduPricing, setEduPricing] = useState(false);
  const [promo, setPromo] = useState<string | null>(null);
  const [lastOrder, setLastOrder] = useState<ShopState["lastOrder"]>(null);

  const go = useCallback((v: View) => {
    setView(v);
    setSearchOpen(false);
    setBagOpen(false);
    requestAnimationFrame(() => window.scrollTo({ top: 0, behavior: "instant" as ScrollBehavior }));
  }, []);

  const pushToast = useCallback((t: Omit<Toast, "id">) => {
    const id = toastSeq++;
    setToasts((prev) => [...prev.slice(-2), { ...t, id }]);
    window.setTimeout(() => setToasts((prev) => prev.filter((x) => x.id !== id)), 4200);
  }, []);

  const dismissToast = useCallback((id: number) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const addToBag = useCallback(
    (line: Omit<BagLine, "key" | "qty">, qty = 1) => {
      const key = `${line.productId}__${line.variant}`;
      setBag((prev) => {
        const found = prev.find((l) => l.key === key);
        if (found) return prev.map((l) => (l.key === key ? { ...l, qty: l.qty + qty } : l));
        return [...prev, { ...line, key, qty }];
      });
      pushToast({ title: "Added to Bag", body: `${line.name} — ${line.variant}` });
    },
    [pushToast]
  );

  const updateQty = useCallback((key: string, qty: number) => {
    setBag((prev) =>
      qty <= 0 ? prev.filter((l) => l.key !== key) : prev.map((l) => (l.key === key ? { ...l, qty } : l))
    );
  }, []);

  const removeLine = useCallback((key: string) => {
    setBag((prev) => prev.filter((l) => l.key !== key));
  }, []);

  const clearBag = useCallback(() => setBag([]), []);

  const toggleWish = useCallback(
    (id: string) => {
      setWishlist((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));
      const p = PRODUCTS.find((x) => x.id === id) ?? ACCESSORIES.find((x) => x.id === id);
      pushToast({ title: wishlist.includes(id) ? "Removed from Saved" : "Saved for later", body: p?.name });
    },
    [pushToast, wishlist]
  );

  const applyPromo = useCallback(
    (code: string) => {
      const c = code.trim().toUpperCase();
      if (c === "HELLOSG10" || c === "EDU2026") {
        setPromo(c);
        pushToast({ title: "Promo applied", body: `${c} — 10% off accessories over S$100` });
        return true;
      }
      pushToast({ title: "Code not recognised", body: "Try HELLOSG10" });
      return false;
    },
    [pushToast]
  );

  const subtotalRaw = useMemo(() => bag.reduce((s, l) => s + l.unitPrice * l.qty, 0), [bag]);
  const eduDiscount = eduPricing ? subtotalRaw * 0.06 : 0;
  const subtotal = subtotalRaw - eduDiscount;
  const gst = subtotal - subtotal / (1 + GST_RATE);

  const placeOrder = useCallback(
    (email: string) => {
      const id = `SG-${Math.floor(100000 + Math.random() * 899999)}`;
      setLastOrder({ id, total: subtotal, email });
      setBag([]);
      return id;
    },
    [subtotal]
  );

  const findProduct = useCallback((id: string) => PRODUCTS.find((p) => p.id === id), []);

  const bagCount = useMemo(() => bag.reduce((s, l) => s + l.qty, 0), [bag]);

  const value: ShopState = {
    view,
    go,
    bag,
    addToBag,
    updateQty,
    removeLine,
    clearBag,
    bagCount,
    subtotal,
    gst,
    wishlist,
    toggleWish,
    toasts,
    pushToast,
    dismissToast,
    searchOpen,
    setSearchOpen,
    bagOpen,
    setBagOpen,
    eduPricing,
    setEduPricing,
    promo,
    applyPromo,
    lastOrder,
    placeOrder,
    findProduct,
  };

  return <ShopCtx.Provider value={value}>{children}</ShopCtx.Provider>;
}

export function useShop(): ShopState {
  const ctx = useContext(ShopCtx);
  if (!ctx) throw new Error("useShop outside provider");
  return ctx;
}

export { fmtSGD };
export const formatSGD = fmtSGD;
