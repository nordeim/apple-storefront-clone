import { useEffect } from "react";
import { X, Accessibility } from "lucide-react";
import { ShopProvider, useShop } from "./lib/shop";
import GlobalNav from "./components/GlobalNav";
import Homepage from "./components/Homepage";
import { StoreHome, CategoryPage, ProductPage, ComparePage, TradeInPage, AccessoriesPage, EntertainmentPage } from "./components/Storefront";
import { SupportPage, StoresPage, CheckoutPage, OrderSuccess, SpecialistWidget } from "./components/Services";
import Footer from "./components/Footer";

function Toasts() {
  const { toasts, dismissToast } = useShop();
  return (
    <div className="fixed bottom-5 left-1/2 z-[80] flex w-full max-w-sm -translate-x-1/2 flex-col gap-2 px-4" aria-live="polite">
      {toasts.map((t) => (
        <div key={t.id} className="toast-in flex items-start gap-3 rounded-2xl bg-[#1d1d1f]/95 p-4 text-white shadow-2xl backdrop-blur">
          <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-[#30d158] text-[13px] font-bold text-black">✓</span>
          <div className="flex-1">
            <p className="text-[14px] font-semibold">{t.title}</p>
            {t.body && <p className="text-[13px] text-white/70">{t.body}</p>}
          </div>
          <button aria-label="Dismiss notification" onClick={() => dismissToast(t.id)} className="rounded p-1 text-white/60 hover:text-white"><X className="h-4 w-4" /></button>
        </div>
      ))}
    </div>
  );
}

function A11yBar() {
  useEffect(() => {
    document.documentElement.style.setProperty("color-scheme", "light");
  }, []);
  return (
    <div className="fixed bottom-5 left-5 z-[60]">
      <details className="group relative">
        <summary className="flex h-11 w-11 cursor-pointer list-none items-center justify-center rounded-full border border-black/10 bg-white shadow-lg hover:shadow-xl [&::-webkit-details-marker]:hidden" aria-label="Accessibility options">
          <Accessibility className="h-5 w-5" />
        </summary>
        <div className="absolute bottom-14 left-0 mb-2 w-56 rounded-2xl border border-black/10 bg-white p-4 shadow-2xl">
          <p className="text-[13px] font-bold">Accessibility</p>
          <button
            onClick={() => {
              const larger = document.body.style.fontSize === "112.5%";
              document.body.style.fontSize = larger ? "" : "112.5%";
            }}
            className="mt-2 w-full rounded-xl bg-black/5 px-3 py-2 text-left text-[13px] hover:bg-black/10"
          >
            Toggle larger text
          </button>
          <button
            onClick={() => {
              const reduce = document.documentElement.dataset.reduceMotion === "1";
              document.documentElement.dataset.reduceMotion = reduce ? "" : "1";
              document.querySelectorAll(".reveal").forEach((el) => el.classList.add("is-visible"));
            }}
            className="mt-2 w-full rounded-xl bg-black/5 px-3 py-2 text-left text-[13px] hover:bg-black/10"
          >
            Reduce motion
          </button>
          <p className="mt-2 text-[11px] text-[#6e6e73]">WCAG 2.2 AA · Keyboard: Tab / Esc / ⌘K</p>
        </div>
      </details>
    </div>
  );
}

function Router() {
  const { view, go } = useShop();

  useEffect(() => {
    const onPop = () => window.scrollTo({ top: 0 });
    window.addEventListener("popstate", onPop);
    return () => window.removeEventListener("popstate", onPop);
  }, []);

  // breadcrumb for sub-pages
  const showCrumb = view.name !== "home";

  return (
    <div className="min-h-screen">
      <GlobalNav />
      {showCrumb && (
        <div className="border-b border-black/5 bg-[#fbfbfd]">
          <div className="mx-auto flex max-w-[1200px] items-center gap-2 px-5 py-2.5 text-[13px] text-[#6e6e73]">
            <button onClick={() => go({ name: "home" })} className="hover:text-black hover:underline">Home</button>
            <span aria-hidden="true">/</span>
            <span className="text-[#1d1d1f] font-medium" aria-current="page">
              {view.name === "store" && "Store"}
              {view.name === "category" && view.family[0].toUpperCase() + view.family.slice(1)}
              {view.name === "product" && "Product"}
              {view.name === "compare" && "Compare"}
              {view.name === "tradein" && "Trade In"}
              {view.name === "accessories" && "Accessories"}
              {view.name === "entertainment" && "Entertainment"}
              {view.name === "support" && "Support"}
              {view.name === "stores" && "Find a Store"}
              {view.name === "checkout" && "Checkout"}
              {view.name === "order-success" && "Order confirmed"}
            </span>
          </div>
        </div>
      )}
      <main id="main" tabIndex={-1} className="outline-none">
        {view.name === "home" && <Homepage />}
        {view.name === "store" && <StoreHome />}
        {view.name === "category" && <CategoryPage key={view.family} family={view.family} />}
        {view.name === "product" && <ProductPage key={view.id} id={view.id} />}
        {view.name === "compare" && <ComparePage />}
        {view.name === "tradein" && <TradeInPage />}
        {view.name === "accessories" && <AccessoriesPage />}
        {view.name === "entertainment" && <EntertainmentPage />}
        {view.name === "support" && <SupportPage />}
        {view.name === "stores" && <StoresPage />}
        {view.name === "checkout" && <CheckoutPage />}
        {view.name === "order-success" && <OrderSuccess orderId={view.orderId} />}
      </main>
      <Footer />
      <SpecialistWidget />
      <A11yBar />
      <Toasts />
    </div>
  );
}

export default function App() {
  return (
    <ShopProvider>
      <Router />
    </ShopProvider>
  );
}
