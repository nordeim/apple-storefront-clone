export interface ProductFinish {
  id: string;
  name: string;
  swatch: string;
  ring?: string;
}

export interface ProductStorage {
  id: string;
  label: string;
  delta: number;
}

export interface Product {
  id: string;
  family: "iphone" | "mac" | "ipad" | "watch" | "airpods" | "home" | "accessories" | "services";
  name: string;
  tagline: string;
  description: string;
  basePrice: number;
  compareAt?: number;
  rating: number;
  reviews: number;
  badge?: string;
  finishes: ProductFinish[];
  storages?: ProductStorage[];
  chips?: string[];
  specs: { label: string; value: string }[];
  highlights: string[];
  gradient: string;
  accent: string;
}

export const SGD = (n: number) =>
  `S$${n.toLocaleString("en-SG", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

export const GST_RATE = 0.09;
export const priceExGST = (inc: number) => inc / (1 + GST_RATE);
export const gstPortion = (inc: number) => inc - priceExGST(inc);

export const NAV_ITEMS = [
  { id: "store", label: "Store" },
  { id: "mac", label: "Mac" },
  { id: "ipad", label: "iPad" },
  { id: "iphone", label: "iPhone" },
  { id: "watch", label: "Watch" },
  { id: "airpods", label: "AirPods" },
  { id: "home", label: "Home" },
  { id: "entertainment", label: "Entertainment" },
  { id: "accessories", label: "Accessories" },
  { id: "support", label: "Support" },
] as const;

export const PRODUCTS: Product[] = [
  {
    id: "iphone-18-pro",
    family: "iphone",
    name: "iPhone 18 Pro",
    tagline: "Pro further.",
    description:
      "Forged in aerospace-grade titanium. A18 Pro chip, Pro Fusion 48MP camera system with 5x Tetraprism zoom, and the brightest ProMotion display ever on iPhone.",
    basePrice: 1799,
    rating: 4.9,
    reviews: 4812,
    badge: "New",
    finishes: [
      { id: "burgundy", name: "Deep Burgundy", swatch: "#5e1a2a" },
      { id: "natural", name: "Natural Titanium", swatch: "#c2bcb2" },
      { id: "black", name: "Black Titanium", swatch: "#3c3c3d" },
      { id: "white", name: "White Titanium", swatch: "#e3e4e6" },
    ],
    storages: [
      { id: "128", label: "128GB", delta: 0 },
      { id: "256", label: "256GB", delta: 0 },
      { id: "512", label: "512GB", delta: 300 },
      { id: "1t", label: "1TB", delta: 600 },
    ],
    chips: ["A18 Pro", "Titanium", "Camera Control", "Apple Intelligence"],
    specs: [
      { label: "Display", value: '6.9" ProMotion XDR · 3000 nits peak' },
      { label: "Chip", value: "A18 Pro · 6-core GPU" },
      { label: "Camera", value: "48MP Fusion · 48MP Ultra Wide · 12MP 5x Tele" },
      { label: "Battery", value: "Up to 33 hrs video playback" },
      { label: "Material", value: "Grade-5 titanium · Ceramic Shield 2" },
      { label: "Connector", value: "USB-C · Thunderbolt 5" },
    ],
    highlights: ["Camera Control", "Apple Intelligence ready", "Action Button", "Emergency SOS via satellite"],
    gradient: "from-[#2a0e18] via-[#7a1f35] to-[#1a1a1e]",
    accent: "#ff9ecf",
  },
  {
    id: "iphone-duo",
    family: "iphone",
    name: "iPhone Duo",
    tagline: "Hello, hello.",
    description:
      "Apple's first foldable. A 5.4-inch cover display that opens into a stunning 7.8-inch Liquid Retina inner display. Two cameras, zero compromise, crease-free UTG.",
    basePrice: 2499,
    rating: 4.8,
    reviews: 1930,
    badge: "Introducing",
    finishes: [
      { id: "ink", name: "Ink Black", swatch: "#1a1a1e" },
      { id: "mist", name: "Mist White", swatch: "#eceef2" },
      { id: "dune", name: "Desert Dune", swatch: "#c9a87a" },
    ],
    storages: [
      { id: "256", label: "256GB", delta: 0 },
      { id: "512", label: "512GB", delta: 300 },
      { id: "1t", label: "1TB", delta: 650 },
    ],
    chips: ["A19", "Foldable", "Titanium hinge", "Apple Intelligence"],
    specs: [
      { label: "Cover display", value: '5.4" OLED · 120Hz' },
      { label: "Inner display", value: '7.8" Foldable Retina · 2000 nits' },
      { label: "Hinge", value: "Titanium liquid-metal · 500k folds rated" },
      { label: "Battery", value: "Up to 28 hrs · 45W fast charge" },
      { label: "Thickness", value: "4.6mm open · 9.2mm closed" },
    ],
    highlights: ["Opens flat, closes silent", "Split View multitasking", "FlexCam selfies", "IPX8 water resistant"],
    gradient: "from-[#0b1026] via-[#2b3a8f] to-[#7dd3fc]",
    accent: "#7dd3fc",
  },
  {
    id: "iphone-18",
    family: "iphone",
    name: "iPhone 18",
    tagline: "Delightfully capable.",
    description:
      "6.3-inch Super Retina XDR, A19 chip, 48MP Fusion camera with 2x Telephoto-quality zoom, and all-day battery in five joyful colours.",
    basePrice: 1299,
    rating: 4.8,
    reviews: 6214,
    finishes: [
      { id: "ultramarine", name: "Ultramarine", swatch: "#3b4fd8" },
      { id: "teal", name: "Teal", swatch: "#2fa8a0" },
      { id: "pink", name: "Pink", swatch: "#f2a7c3" },
      { id: "white", name: "White", swatch: "#f5f5f7" },
      { id: "black", name: "Black", swatch: "#1d1d1f" },
    ],
    storages: [
      { id: "128", label: "128GB", delta: 0 },
      { id: "256", label: "256GB", delta: 150 },
      { id: "512", label: "512GB", delta: 450 },
    ],
    chips: ["A19", "Dynamic Island", "48MP Fusion"],
    specs: [
      { label: "Display", value: '6.3" Super Retina XDR · 2000 nits' },
      { label: "Chip", value: "A19 · 5-core GPU" },
      { label: "Camera", value: "48MP Fusion · 12MP Ultra Wide" },
      { label: "Battery", value: "Up to 26 hrs video" },
    ],
    highlights: ["Dynamic Island", "Crash Detection", "USB-C", "Ceramic Shield"],
    gradient: "from-[#101828] via-[#1d4ed8] to-[#06b6d4]",
    accent: "#60a5fa",
  },
  {
    id: "macbook-pro-14-m6",
    family: "mac",
    name: 'MacBook Pro 14"',
    tagline: "Mind-blowing. Head-turning.",
    description:
      "M6 chip with 10-core CPU and 12-core GPU. PROLED XDR display with 1600-nit sustained brightness, up to 24GB unified memory, and 22 hours of battery.",
    basePrice: 2599,
    rating: 4.9,
    reviews: 3210,
    badge: "M6 inside",
    finishes: [
      { id: "space-black", name: "Space Black", swatch: "#2e2c2e" },
      { id: "silver", name: "Silver", swatch: "#e3e4e6" },
    ],
    storages: [
      { id: "512", label: "512GB SSD", delta: 0 },
      { id: "1t", label: "1TB SSD", delta: 300 },
      { id: "2t", label: "2TB SSD", delta: 900 },
    ],
    chips: ["Apple M6", "PROLED XDR", "22-hr battery"],
    specs: [
      { label: "Chip", value: "Apple M6 · 10C CPU / 12C GPU" },
      { label: "Display", value: '14.2" PROLED XDR · 120Hz · 3000 nits peak' },
      { label: "Memory", value: "16GB unified · configurable to 36GB" },
      { label: "Battery", value: "Up to 22 hrs · 70W fast charge" },
      { label: "Ports", value: "3× Thunderbolt 5 · HDMI · SDXC · MagSafe 3" },
    ],
    highlights: ["PROLED XDR", "Liquid Retina", "1080p Centre Stage camera", "Six-speaker sound"],
    gradient: "from-black via-[#1c1c22] to-[#3a3a45]",
    accent: "#c7c9ff",
  },
  {
    id: "macbook-air-15-m5",
    family: "mac",
    name: 'MacBook Air 15"',
    tagline: "Featherweight. Heavyweight power.",
    description:
      "Just 11.5mm thin. M5 chip, 15.3-inch Liquid Retina display, MagSafe charging and silent fanless design. In Midnight, Starlight, Silver and Sky Blue.",
    basePrice: 1799,
    compareAt: 1899,
    rating: 4.9,
    reviews: 5411,
    finishes: [
      { id: "midnight", name: "Midnight", swatch: "#2e3641" },
      { id: "starlight", name: "Starlight", swatch: "#e8ddd0" },
      { id: "sky", name: "Sky Blue", swatch: "#a9c6e8" },
      { id: "silver", name: "Silver", swatch: "#e3e4e6" },
    ],
    storages: [
      { id: "256", label: "256GB SSD", delta: 0 },
      { id: "512", label: "512GB SSD", delta: 300 },
      { id: "1t", label: "1TB SSD", delta: 600 },
    ],
    chips: ["Apple M5", "Fanless", "15.3-inch"],
    specs: [
      { label: "Chip", value: "Apple M5 · 10C CPU / 10C GPU" },
      { label: "Display", value: '15.3" Liquid Retina · 500 nits' },
      { label: "Weight", value: "1.51 kg · 11.5mm thin" },
      { label: "Battery", value: "Up to 18 hrs" },
    ],
    highlights: ["Fanless silence", "MagSafe 3", "Touch ID", "Apple Intelligence"],
    gradient: "from-[#0f172a] via-[#334155] to-[#94a3b8]",
    accent: "#bae6fd",
  },
  {
    id: "ipad-a16",
    family: "ipad",
    name: "iPad",
    tagline: "Lovable. Drawable. Magical.",
    description:
      "Now with the A16 chip and double the starting storage. 11-inch Liquid Retina display, Touch ID, and support for Apple Pencil and Magic Keyboard Folio.",
    basePrice: 499,
    rating: 4.7,
    reviews: 8920,
    finishes: [
      { id: "blue", name: "Blue", swatch: "#5b8fd4" },
      { id: "pink", name: "Pink", swatch: "#efa9c6" },
      { id: "yellow", name: "Yellow", swatch: "#f0d060" },
      { id: "silver", name: "Silver", swatch: "#e3e4e6" },
    ],
    storages: [
      { id: "128", label: "128GB", delta: 0 },
      { id: "256", label: "256GB", delta: 150 },
    ],
    chips: ["A16", "Touch ID", "USB-C"],
    specs: [
      { label: "Display", value: '11" Liquid Retina · 500 nits' },
      { label: "Chip", value: "A16 Bionic" },
      { label: "Camera", value: "12MP Wide · Landscape 12MP front" },
      { label: "Storage", value: "128GB starting — 2× before" },
    ],
    highlights: ["Apple Pencil (USB-C)", "Magic Keyboard Folio", "All-day battery"],
    gradient: "from-[#fef3c7] via-[#f9a8d4] to-[#93c5fd]",
    accent: "#f472b6",
  },
  {
    id: "ipad-pro-m5",
    family: "ipad",
    name: "iPad Pro 11\"",
    tagline: "Beyond Pro.",
    description:
      "M5 chip, Ultra Retina XDR Tandem OLED, nano-texture option, and Apple Pencil Pro with barrel roll and squeeze. Thinnest Apple product ever at 5.3mm.",
    basePrice: 1499,
    rating: 4.9,
    reviews: 2104,
    badge: "M5",
    finishes: [
      { id: "space-black", name: "Space Black", swatch: "#2e2c2e" },
      { id: "silver", name: "Silver", swatch: "#e3e4e6" },
    ],
    storages: [
      { id: "256", label: "256GB", delta: 0 },
      { id: "512", label: "512GB", delta: 300 },
      { id: "1t", label: "1TB", delta: 900 },
    ],
    chips: ["Apple M5", "Tandem OLED", "Pencil Pro"],
    specs: [
      { label: "Display", value: '11" Ultra Retina XDR · Tandem OLED · 1600 nits' },
      { label: "Chip", value: "Apple M5 · 10C GPU · 16C Neural Engine" },
      { label: "Thickness", value: "5.3 mm · 444 g" },
      { label: "Camera", value: "12MP Wide · LiDAR · 4K ProRes" },
    ],
    highlights: ["Apple Pencil Pro", "Magic Keyboard", "Thunderbolt / USB 4"],
    gradient: "from-black via-[#312e81] to-[#a5b4fc]",
    accent: "#a5b4fc",
  },
  {
    id: "watch-s12",
    family: "watch",
    name: "Apple Watch Series 12",
    tagline: "Smarter. Brighter. Mightier.",
    description:
      "Most accurate heart-rate sensing in a wearable. S12 SiP, double-tap gesture,3,000-nit display, sleep apnoea notifications and precision dual-frequency GPS.",
    basePrice: 599,
    rating: 4.8,
    reviews: 3120,
    finishes: [
      { id: "bronze", name: "Dark Bronze Aluminium", swatch: "#6b543e" },
      { id: "midnight", name: "Midnight Aluminium", swatch: "#2e3641" },
      { id: "starlight", name: "Starlight Aluminium", swatch: "#e8ddd0" },
    ],
    storages: [
      { id: "41", label: "41mm", delta: 0 },
      { id: "45", label: "45mm", delta: 60 },
    ],
    chips: ["S12 SiP", "watchOS 12", "3000 nits"],
    specs: [
      { label: "Case", value: "41 / 45mm aluminium · 50m water resistant" },
      { label: "Display", value: "Always-On Retina · 3000 nits" },
      { label: "Health", value: "ECG · Blood oxygen · Sleep apnoea · HR" },
      { label: "Battery", value: "Up to 36 hrs Low Power Mode" },
    ],
    highlights: ["Double tap", "Precision Finding for iPhone", "Crash Detection"],
    gradient: "from-[#1c1917] via-[#57534e] to-[#a8a29e]",
    accent: "#fdba74",
  },
  {
    id: "watch-ultra-3",
    family: "watch",
    name: "Apple Watch Ultra 3",
    tagline: "Adventure awaits.",
    description:
      "49mm aerospace titanium, 4000-nit display, satellite messaging, 72-hour Low Power Mode and the most accurate GPS in a sports watch.",
    basePrice: 1199,
    rating: 4.9,
    reviews: 1450,
    badge: "Titanium",
    finishes: [
      { id: "natural", name: "Natural Titanium", swatch: "#c2bcb2" },
      { id: "black", name: "Black Titanium", swatch: "#2b2b2d" },
    ],
    storages: [{ id: "49", label: "49mm", delta: 0 }],
    chips: ["S12 SiP", "100m WR", "Titanium"],
    specs: [
      { label: "Case", value: "49mm titanium · 100m WR · MIL-STD 810H" },
      { label: "Display", value: "4000 nits · Always-On" },
      { label: "Battery", value: "Up to 72 hrs Low Power" },
      { label: "Bands", value: "Alpine · Trail · Ocean" },
    ],
    highlights: ["Action Button", "Depth gauge", "Dual-frequency GPS", "Siren 86dB"],
    gradient: "from-[#082f49] via-[#0369a1] to-[#f97316]",
    accent: "#fb923c",
  },
  {
    id: "airpods-pro-3",
    family: "airpods",
    name: "AirPods Pro 3",
    tagline: "Silence, perfected.",
    description:
      "World's best in-ear Active Noise Cancellation — 2× stronger. H3 chip, heart-rate sensing, Live Translation and dust/sweat/water resistant.",
    basePrice: 349,
    rating: 4.8,
    reviews: 7210,
    finishes: [{ id: "white", name: "White", swatch: "#f5f5f7" }],
    chips: ["H3", "2× ANC", "Heart-rate"],
    specs: [
      { label: "ANC", value: "2× stronger · Adaptive Transparency" },
      { label: "Chip", value: "H3 · U2 · Skin-detect" },
      { label: "Battery", value: "Up to 30 hrs with case · MagSafe + USB-C" },
      { label: "Fit", value: "4 ear-tip sizes · IP57" },
    ],
    highlights: ["Live Translation", "Conversation Awareness", "Wireless charging"],
    gradient: "from-[#f8fafc] via-[#e2e8f0] to-[#94a3b8]",
    accent: "#0ea5e9",
  },
  {
    id: "homeview",
    family: "home",
    name: "Apple HomeView",
    tagline: "Designed for life at home.",
    description:
      "A delightful 7-inch smart display with Apple Intelligence, built-in camera shutter, HomeKit Secure Video and room-filling Spatial Audio base.",
    basePrice: 449,
    rating: 4.7,
    reviews: 890,
    badge: "New",
    finishes: [
      { id: "white", name: "White", swatch: "#f5f5f7" },
      { id: "midnight", name: "Midnight", swatch: "#2e3641" },
      { id: "blue", name: "Sky", swatch: "#a9c6e8" },
      { id: "orange", name: "Sunset", swatch: "#fb923c" },
    ],
    chips: ["A18", "HomeKit", "Siri"],
    specs: [
      { label: "Display", value: '7" 2K · Anti-glare · Presence sensing' },
      { label: "Audio", value: "Spatial Audio woofer + tweeters" },
      { label: "Camera", value: "12MP Centre Stage · Physical shutter" },
      { label: "Hub", value: "Thread · Matter · Zigbee built-in" },
    ],
    highlights: ["StandBy widgets", "Intercom", "Secure Video", "Apple TV remote"],
    gradient: "from-[#fef9c3] via-[#fdba74] to-[#38bdf8]",
    accent: "#f59e0b",
  },
  {
    id: "macbook-pro-m6-side",
    family: "mac",
    name: "MacBook Pro 14\" M6",
    tagline: "14-inch model now with M6.",
    description:
      "Same pro chassis, new M6 efficiency. Configure with up to 36GB memory and 2TB storage. Ideal for Xcode, Final Cut and on-device AI.",
    basePrice: 2299,
    rating: 4.8,
    reviews: 1204,
    finishes: [
      { id: "space-black", name: "Space Black", swatch: "#2e2c2e" },
      { id: "silver", name: "Silver", swatch: "#e3e4e6" },
    ],
    storages: [
      { id: "512", label: "512GB SSD", delta: 0 },
      { id: "1t", label: "1TB SSD", delta: 300 },
    ],
    chips: ["Apple M6", "XDR"],
    specs: [
      { label: "Chip", value: "M6 · 10C CPU" },
      { label: "Display", value: '14.2" Liquid XDR' },
      { label: "Battery", value: "Up to 20 hrs" },
    ],
    highlights: ["SDXC slot", "HDMI 2.1", "Wi-Fi 7"],
    gradient: "from-[#18181b] via-[#52525b] to-[#a1a1aa]",
    accent: "#d4d4d8",
  },
];

export interface Accessory {
  id: string;
  name: string;
  price: number;
  category: string;
  colors: string[];
  rating: number;
  blurb: string;
  tag?: string;
}

export const ACCESSORIES: Accessory[] = [
  { id: "acc-magsafe", name: "MagSafe Charger (2m)", price: 65, category: "Charging", colors: ["#f5f5f7"], rating: 4.7, blurb: "25W faster wireless charging with Qi2.", tag: "Best seller" },
  { id: "acc-case-18pro", name: "iPhone 18 Pro Clear Case", price: 75, category: "Cases", colors: ["#e3e4e6", "#5e1a2a", "#3b4fd8"], rating: 4.6, blurb: "Crystal-clear with Camera Control cutout." },
  { id: "acc-leather-wallet", name: "iPhone Wallet with MagSafe", price: 89, category: "Cases", colors: ["#5e1a2a", "#1d1d1f", "#c9a87a"], rating: 4.5, blurb: "FineWoven-free microtwill, Find My built in." },
  { id: "acc-pencil-pro", name: "Apple Pencil Pro", price: 199, category: "iPad", colors: ["#f5f5f7"], rating: 4.9, blurb: "Squeeze, barrel roll and haptic feedback.", tag: "New" },
  { id: "acc-magic-kb", name: "Magic Keyboard for iPad Pro", price: 499, category: "iPad", colors: ["#1d1d1f", "#f5f5f7"], rating: 4.8, blurb: "Aluminium palm rest, function row, haptics." },
  { id: "acc-airtag", name: "AirTag (4 pack)", price: 149, category: "Find My", colors: ["#f5f5f7"], rating: 4.9, blurb: "Keep track of keys, bags and bikes.", tag: "Bundle" },
  { id: "acc-studio-display", name: "Studio Display Nano", price: 2299, category: "Mac", colors: ["#e3e4e6"], rating: 4.8, blurb: "27-inch 5K, nano-texture, 12MP camera." },
  { id: "acc-watch-band", name: "Trail Loop — Green/Grey", price: 139, category: "Watch", colors: ["#4d7c0f", "#57534e"], rating: 4.7, blurb: "Light, breathable, endlessly adjustable." },
  { id: "acc-airpods-max", name: "AirPods Max — Midnight", price: 799, category: "Audio", colors: ["#2e3641", "#e8ddd0", "#fb923c"], rating: 4.7, blurb: "High-fidelity audio, H2 + ANC, USB-C." },
  { id: "acc-140w", name: "140W USB-C Power Adapter", price: 139, category: "Charging", colors: ["#f5f5f7"], rating: 4.6, blurb: "Fast-charge MacBook Pro 16 over MagSafe." },
];

export const SG_STORES = [
  { id: "orchard", name: "Apple Orchard Road", address: "270 Orchard Road, Singapore 238857", mrt: "Orchard · NS22", hours: "10:00 – 22:00 daily", phone: "1800 692 7753", stockNote: " pickup in 1 hour" },
  { id: "mbs", name: "Apple Marina Bay Sands", address: "2 Bayfront Avenue, B2-06, Singapore 018972", mrt: "Bayfront · CE1", hours: "10:00 – 22:00 daily", phone: "1800 692 7753", stockNote: "waterside pickup" },
  { id: "jewel", name: "Apple Jewel Changi Airport", address: "78 Airport Blvd, #02-234/235, Singapore 819666", mrt: "Changi Airport · CG2", hours: "10:00 – 22:00 daily", phone: "1800 692 7753", stockNote: "fly-through pickup" },
];

export const TRADE_IN_MAP: Record<string, { label: string; max: number }> = {
  "iphone-15-pro": { label: "iPhone 15 Pro / Max", max: 880 },
  "iphone-14": { label: "iPhone 14 / Plus", max: 520 },
  "iphone-13": { label: "iPhone 13", max: 380 },
  "iphone-12": { label: "iPhone 12", max: 260 },
  "macbook-pro": { label: "MacBook Pro (M-series)", max: 1150 },
  "macbook-air": { label: "MacBook Air (M-series)", max: 720 },
  "ipad-pro": { label: "iPad Pro", max: 640 },
  "watch-ultra": { label: "Apple Watch Ultra", max: 420 },
  "watch-s9": { label: "Apple Watch S9 / later", max: 240 },
};

export const ENTERTAINMENT = [
  { id: "tv-plus", title: "Apple TV+", subtitle: "Severance · Slow Horses · Pachinko", cta: "Try 3 months free", gradient: "from-black via-[#111827] to-[#1f2937]", duration: "4K Dolby Vision" },
  { id: "music", title: "Apple Music", subtitle: "100M songs. Spatial Audio.", cta: "Listen now", gradient: "from-[#7c2d12] via-[#dc2626] to-[#f472b6]", duration: "Lossless" },
  { id: "arcade", title: "Apple Arcade", subtitle: "200+ games. No ads.", cta: "Play", gradient: "from-[#0f172a] via-[#7c3aed] to-[#ec4899]", duration: "Family sharing" },
  { id: "fitness", title: "Apple Fitness+", subtitle: "Train with top coaches", cta: "Move", gradient: "from-[#052e16] via-[#16a34a] to-[#a3e635]", duration: "Watch + iPhone" },
  { id: "news", title: "Apple News+", subtitle: "Magazines & puzzles", cta: "Read", gradient: "from-[#172554] via-[#2563eb] to-[#7dd3fc]", duration: "Offline" },
  { id: "one", title: "Apple One", subtitle: "Bundle & save up to S$12/mo", cta: "Bundle", gradient: "from-black via-[#374151] to-white", duration: "iCloud+ 2TB" },
];

export function searchCatalog(q: string): Product[] {
  const needle = q.trim().toLowerCase();
  if (!needle) return [];
  return PRODUCTS.filter(
    (p) =>
      p.name.toLowerCase().includes(needle) ||
      p.tagline.toLowerCase().includes(needle) ||
      p.family.includes(needle) ||
      p.chips?.some((c) => c.toLowerCase().includes(needle)) ||
      p.description.toLowerCase().includes(needle)
  ).slice(0, 6);
}
