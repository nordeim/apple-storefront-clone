import { useShop } from "../lib/shop";

const COLS: { title: string; links: { label: string; view?: "store" | "support" | "stores" | "tradein" | "compare" | "accessories" | "entertainment"; family?: string }[] }[] = [
  {
    title: "Shop and Learn",
    links: [
      { label: "Store", view: "store" },
      { label: "Mac", family: "mac" },
      { label: "iPad", family: "ipad" },
      { label: "iPhone", family: "iphone" },
      { label: "Watch", family: "watch" },
      { label: "AirPods", family: "airpods" },
      { label: "Accessories", view: "accessories" },
    ],
  },
  {
    title: "Services",
    links: [
      { label: "Apple Music", view: "entertainment" },
      { label: "Apple TV+", view: "entertainment" },
      { label: "Apple Arcade", view: "entertainment" },
      { label: "iCloud+", view: "entertainment" },
      { label: "Apple One", view: "entertainment" },
      { label: "AppleCare+", view: "support" },
    ],
  },
  {
    title: "Apple Store",
    links: [
      { label: "Find a Store", view: "stores" },
      { label: "Genius Bar", view: "support" },
      { label: "Today at Apple", view: "stores" },
      { label: "Apple Trade In", view: "tradein" },
      { label: "Order Status", view: "stores" },
      { label: "Shopping Help", view: "support" },
    ],
  },
  {
    title: "About Apple",
    links: [
      { label: "Newsroom", view: "support" },
      { label: "Careers (Singapore)", view: "support" },
      { label: "Ethics & Compliance", view: "support" },
      { label: "Privacy", view: "support" },
      { label: "Environment", view: "support" },
    ],
  },
];

export default function Footer() {
  const { go } = useShop();
  return (
    <footer className="bg-[#f5f5f7] text-[12px] text-[#6e6e73]" aria-label="Apple Singapore footer">
      <div className="mx-auto max-w-[1024px] px-5 py-6">
        <div className="space-y-2 border-b border-[#d2d2d7] pb-4 leading-relaxed">
          <p>* Heart-rate accuracy claim based on independent lab testing vs. leading wearables, Sept 2026. Requires iPhone 12 or later.</p>
          <p>◊◊ Monthly pricing before trade-in, over 24 months at 0% with eligible cards. Education pricing available to students, parents and educators. All prices include 9% GST (Reg. No. 201234567K). Delivery estimates for Singapore addresses.</p>
          <p>Apple Pickup available on in-stock items at Apple Orchard Road, Apple Marina Bay Sands and Apple Jewel Changi Airport. Trade In values vary by condition; recycling free for any device.</p>
        </div>
        <nav className="grid grid-cols-2 gap-6 border-b border-[#d2d2d7] py-6 sm:grid-cols-4" aria-label="Footer">
          {COLS.map((c) => (
            <div key={c.title}>
              <h2 className="font-semibold text-[#1d1d1f]">{c.title}</h2>
              <ul className="mt-2 space-y-2">
                {c.links.map((l) => (
                  <li key={l.label}>
                    <button
                      onClick={() => {
                        if (l.view) go({ name: l.view } as never);
                        else if (l.family) go({ name: "category", family: l.family });
                      }}
                      className="hover:text-[#1d1d1f] hover:underline"
                    >
                      {l.label}
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </nav>
        <p className="pt-4">More ways to shop: <a className="text-[#0066cc] hover:underline" href="tel:18006927753">1800 692 7753</a> · <button className="text-[#0066cc] hover:underline" onClick={() => go({ name: "stores" })}>Find an Apple Store</button> · <button className="text-[#0066cc] hover:underline" onClick={() => go({ name: "support" })}>Chat with a Specialist</button></p>
        <div className="mt-3 flex flex-col gap-2 border-t border-[#d2d2d7] pt-4 sm:flex-row sm:items-center sm:justify-between">
          <p>Copyright © 2026 Apple Inc. All rights reserved. · Singapore · English | 中文</p>
          <ul className="flex flex-wrap gap-x-3 gap-y-1">
            {["Privacy Policy", "Terms of Use", "Sales Policy", "Legal", "Site Map"].map((l, i, a) => (
              <li key={l} className="flex gap-3">
                <button className="hover:underline">{l}</button>
                {i < a.length - 1 && <span aria-hidden="true" className="text-[#d2d2d7]">|</span>}
              </li>
            ))}
          </ul>
        </div>
        <p className="mt-2 text-[11px]">UEN 201234567K · GST-inclusive pricing · PDPA-compliant · IMDA-certified data erasure for Trade In. Demo storefront — no real charges.</p>
      </div>
    </footer>
  );
}
