import { useMemo, useState } from "react";
import { Check, Heart, Truck, ShieldCheck, RefreshCcw, ChevronRight, Star, Minus, Plus, Info, CreditCard, MapPin, Sparkles, ArrowLeftRight, Calculator } from "lucide-react";
import { PRODUCTS, ACCESSORIES, SG_STORES, TRADE_IN_MAP, SGD, GST_RATE, type Product } from "../data/catalog";
import { useShop } from "../lib/shop";
import { cn } from "../utils/cn";

export function Stars({ rating }: { rating: number }) {
  return (
    <span className="inline-flex items-center gap-1" aria-label={`Rated ${rating} out of 5`}>
      {Array.from({ length: 5 }).map((_, i) => (
        <Star key={i} className={cn("h-3.5 w-3.5", i < Math.round(rating) ? "fill-[#fa9a28] text-[#fa9a28]" : "fill-[#d2d2d7] text-[#d2d2d7]")} />
      ))}
    </span>
  );
}

export function StoreHome() {
  const { go, addToBag } = useShop();
  const families = [
    { id: "mac", label: "Mac", blurb: "M6 power", grad: "from-[#0f172a] to-[#475569]" },
    { id: "iphone", label: "iPhone", blurb: "18 Pro · Duo", grad: "from-[#7c2d12] to-[#db2777]" },
    { id: "ipad", label: "iPad", blurb: "A16 · M5", grad: "from-[#0ea5e9] to-[#a78bfa]" },
    { id: "watch", label: "Watch", blurb: "Series 12", grad: "from-[#14532d] to-[#65a30d]" },
    { id: "airpods", label: "AirPods", blurb: "Pro 3", grad: "from-[#334155] to-[#94a3b8]" },
    { id: "home", label: "Home", blurb: "HomeView", grad: "from-[#f59e0b] to-[#ef4444]" },
  ];
  return (
    <div className="bg-[#f5f5f7]">
      <div className="mx-auto max-w-[1200px] px-5 pb-14 pt-10">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <h1 className="text-[40px] font-bold leading-[1.05] tracking-tight sm:text-[56px]">
            Store. <span className="text-[#6e6e73]">The best way to buy the products you love.</span>
          </h1>
          <div className="flex gap-6 text-[13px]">
            <span className="flex items-center gap-2"><span className="flex h-9 w-9 items-center justify-center rounded-full bg-white shadow">◉</span> Specialist help</span>
            <span className="flex items-center gap-2"><Truck className="h-5 w-5" /> Free delivery</span>
          </div>
        </div>

        <div className="no-scrollbar mt-8 flex gap-4 overflow-x-auto pb-2" role="list">
          {families.map((f) => (
            <button key={f.id} role="listitem" onClick={() => go({ name: "category", family: f.id })} className="group w-36 shrink-0 text-center">
              <span className={cn("mx-auto flex h-28 w-28 items-center justify-center rounded-full bg-gradient-to-br text-[28px] font-black text-white shadow-lg transition group-hover:scale-105", f.grad)} aria-hidden="true">
                {f.label[0]}
              </span>
              <span className="mt-2 block text-[15px] font-semibold">{f.label}</span>
              <span className="block text-[13px] text-[#6e6e73]">{f.blurb}</span>
            </button>
          ))}
        </div>

        <h2 className="mt-12 text-[24px] font-bold tracking-tight">The latest. Fresh out of the lab.</h2>
        <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {PRODUCTS.slice(0, 6).map((p) => (
            <article key={p.id} className="lift cursor-pointer rounded-2xl bg-white p-6 shadow-sm" onClick={() => go({ name: "product", id: p.id })}>
              {p.badge && <span className="text-[12px] font-semibold text-[#b00020]">{p.badge}</span>}
              <h3 className="text-[19px] font-bold">{p.name}</h3>
              <p className="text-[14px] text-[#6e6e73]">{p.tagline}</p>
              <div className={cn("mt-4 h-44 rounded-2xl bg-gradient-to-br", p.gradient)} aria-hidden="true" />
              <div className="mt-4 flex items-center justify-between">
                <p className="text-[15px] font-semibold">From {SGD(p.basePrice)}</p>
                <button
                  onClick={(e) => { e.stopPropagation(); addToBag({ productId: p.id, name: p.name, variant: `${p.finishes[0].name} · ${p.storages?.[0].label ?? "Standard"}`, unitPrice: p.basePrice, imageGradient: p.gradient }); }}
                  className="btn-apple-blue px-5 py-1.5 text-[14px]"
                >
                  Buy
                </button>
              </div>
            </article>
          ))}
        </div>

        <div className="mt-8 grid grid-cols-1 gap-4 md:grid-cols-2">
          <button onClick={() => go({ name: "tradein" })} className="flex items-center justify-between rounded-2xl bg-black p-7 text-left text-white">
            <span><span className="flex items-center gap-2 text-[13px] uppercase tracking-widest text-white/60"><RefreshCcw className="h-4 w-4" /> Apple Trade In</span><span className="mt-1 block text-[24px] font-bold">Get S$80–S$1,150 credit.</span><span className="mt-1 block text-white/70 text-[14px]">Estimate in 30 seconds.</span></span>
            <ChevronRight className="h-6 w-6" />
          </button>
          <button onClick={() => go({ name: "compare" })} className="flex items-center justify-between rounded-2xl bg-white p-7 text-left shadow-sm">
            <span><span className="flex items-center gap-2 text-[13px] uppercase tracking-widest text-[#6e6e73]"><ArrowLeftRight className="h-4 w-4" /> Compare</span><span className="mt-1 block text-[24px] font-bold">Which iPhone is for you?</span><span className="mt-1 block text-[#6e6e73] text-[14px]">Side-by-side specs & pricing.</span></span>
            <ChevronRight className="h-6 w-6" />
          </button>
        </div>
      </div>
    </div>
  );
}

export function CategoryPage({ family }: { family: string }) {
  const { go, addToBag, wishlist, toggleWish } = useShop();
  const [sort, setSort] = useState<"featured" | "low" | "high" | "rating">("featured");
  const items = useMemo(() => {
    const list = PRODUCTS.filter((p) => p.family === family || (family === "store" && true));
    const sorted = [...list];
    if (sort === "low") sorted.sort((a, b) => a.basePrice - b.basePrice);
    if (sort === "high") sorted.sort((a, b) => b.basePrice - a.basePrice);
    if (sort === "rating") sorted.sort((a, b) => b.rating - a.rating);
    return sorted;
  }, [family, sort]);

  const titleMap: Record<string, string> = { mac: "Mac", iphone: "iPhone", ipad: "iPad", watch: "Watch", airpods: "AirPods", home: "Home & Audio", accessories: "Accessories" };

  return (
    <div className="bg-[#fbfbfd]">
      <div className="mx-auto max-w-[1200px] px-5 py-10">
        <p className="text-[13px] text-[#6e6e73]">Apple Store Singapore / {titleMap[family] ?? family}</p>
        <div className="mt-1 flex flex-wrap items-end justify-between gap-4">
          <h1 className="text-[36px] font-bold tracking-tight sm:text-[48px]">{titleMap[family] ?? "Shop"}</h1>
          <label className="flex items-center gap-2 text-[14px]">Sort
            <select value={sort} onChange={(e) => setSort(e.target.value as typeof sort)} className="rounded-full border border-black/15 bg-white px-3 py-1.5 text-[14px]" aria-label="Sort products">
              <option value="featured">Featured</option>
              <option value="low">Price: Low to High</option>
              <option value="high">Price: High to Low</option>
              <option value="rating">Top Rated</option>
            </select>
          </label>
        </div>
        {items.length === 0 && <p className="mt-10 text-center text-[#6e6e73]">No products in this family yet — explore the Store.</p>}
        <div className="mt-6 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {items.map((p) => (
            <article key={p.id} className="lift flex flex-col rounded-2xl bg-white p-6 shadow-sm ring-1 ring-black/5">
              <div className={cn("h-52 rounded-2xl bg-gradient-to-br", p.gradient)} aria-hidden="true" />
              <div className="mt-4 flex items-start justify-between gap-2">
                <div>
                  {p.badge && <p className="text-[12px] font-semibold text-[#b00020]">{p.badge}</p>}
                  <h2 className="text-[20px] font-bold leading-tight">{p.name}</h2>
                  <p className="text-[14px] text-[#6e6e73]">{p.tagline}</p>
                </div>
                <button aria-label={`Save ${p.name}`} onClick={() => toggleWish(p.id)} className="rounded-full bg-black/5 p-2 hover:bg-black/10">
                  <Heart className={cn("h-4 w-4", wishlist.includes(p.id) ? "fill-red-500 text-red-500" : "text-[#6e6e73]")} />
                </button>
              </div>
              <div className="mt-2 flex items-center gap-2"><Stars rating={p.rating} /><span className="text-[13px] text-[#6e6e73]">{p.rating} ({p.reviews.toLocaleString()})</span></div>
              <p className="mt-2 text-[15px] font-semibold">From {SGD(p.basePrice)} <span className="font-normal text-[#6e6e73] text-[13px]">incl. GST</span></p>
              <div className="mt-4 flex gap-2">
                <button onClick={() => go({ name: "product", id: p.id })} className="btn-apple-outline flex-1 py-2 text-[14px]">Learn more</button>
                <button onClick={() => addToBag({ productId: p.id, name: p.name, variant: `${p.finishes[0].name} · ${p.storages?.[0].label ?? "Standard"}`, unitPrice: p.basePrice, imageGradient: p.gradient })} className="btn-apple-blue flex-1 py-2 text-[14px]">Buy</button>
              </div>
            </article>
          ))}
        </div>
      </div>
    </div>
  );
}

export function ProductPage({ id }: { id: string }) {
  const { go, addToBag, toggleWish, wishlist, eduPricing } = useShop();
  const product = PRODUCTS.find((p) => p.id === id) ?? PRODUCTS[0];
  const [finish, setFinish] = useState(product.finishes[0]);
  const [storage, setStorage] = useState(product.storages?.[0] ?? null);
  const [appleCare, setAppleCare] = useState(false);
  const [engraving, setEngraving] = useState("");
  const [pickup, setPickup] = useState(SG_STORES[0].id);
  const [fulfilment, setFulfilment] = useState<"delivery" | "pickup">("delivery");
  const [qty, setQty] = useState(1);

  // reset when product changes
  // (keyed by parent via key prop — state initialises per product)

  const unit = product.basePrice + (storage?.delta ?? 0);
  const carePrice = product.family === "mac" ? 399 : product.family === "iphone" ? 299 : 149;
  const eduUnit = eduPricing ? unit * 0.94 : unit;
  const total = (eduUnit + (appleCare ? carePrice : 0)) * qty;
  const monthly = total / 24;
  const saved = wishlist.includes(product.id);
  const related = PRODUCTS.filter((p) => p.family === product.family && p.id !== product.id).slice(0, 3);

  return (
    <div className="bg-white">
      <div className="border-b border-black/5 bg-[#f5f5f7]">
        <div className="mx-auto flex max-w-[1200px] items-center justify-between px-5 py-3">
          <p className="text-[19px] font-bold">{product.name}</p>
          <div className="flex items-center gap-3 text-[13px]">
            <span className="hidden sm:inline text-[#6e6e73]">From {SGD(eduUnit)}/mo. {SGD(monthly)}/mo. × 24</span>
            <button onClick={() => addToBag({ productId: product.id, name: product.name, variant: `${finish.name} · ${storage?.label ?? "Standard"}${appleCare ? " · AppleCare+" : ""}`, unitPrice: eduUnit + (appleCare ? carePrice : 0), imageGradient: product.gradient, meta: fulfilment === "pickup" ? `Pickup: ${SG_STORES.find((s) => s.id === pickup)?.name}` : "Free delivery" }, qty)} className="btn-apple-blue px-4 py-1.5">Buy</button>
          </div>
        </div>
      </div>

      <div className="mx-auto grid max-w-[1200px] grid-cols-1 gap-10 px-5 py-10 lg:grid-cols-2">
        {/* Visual */}
        <div className="lg:sticky lg:top-24 lg:self-start">
          <div className={cn("relative flex min-h-[420px] flex-col items-center justify-center overflow-hidden rounded-3xl bg-gradient-to-br p-8 sm:min-h-[520px]", product.gradient)}>
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_20%,rgba(255,255,255,0.25),transparent_60%)]" aria-hidden="true" />
            {product.badge && <span className="absolute left-5 top-5 rounded-full bg-white/15 px-3 py-1 text-[12px] font-semibold text-white backdrop-blur">{product.badge}</span>}
            <button onClick={() => toggleWish(product.id)} aria-label="Save" className="absolute right-5 top-5 rounded-full bg-white/15 p-2.5 text-white backdrop-blur hover:bg-white/30">
              <Heart className={cn("h-4 w-4", saved && "fill-red-400 text-red-400")} />
            </button>
            {/* Device mock */}
            <div className="relative z-10 text-center">
              {product.family === "watch" ? (
                <div className="mx-auto flex h-64 w-44 flex-col items-center">
                  <div className="h-12 w-10 rounded-t-2xl bg-black/40" />
                  <div className="flex h-48 w-44 items-center justify-center rounded-[36px] bg-black p-2 shadow-2xl ring-4 ring-white/10">
                    <div className="flex h-full w-full flex-col items-center justify-center rounded-[28px] bg-gradient-to-b from-[#111] to-black text-white">
                      <p className="text-3xl font-bold">9:41</p>
                      <p className="text-[11px] text-white/60">Tue 9 Sep</p>
                      <div className="mt-3 grid grid-cols-4 gap-1.5">{Array.from({ length: 8 }).map((_, i) => <span key={i} className="h-7 w-7 rounded-full" style={{ background: ["#f97316", "#22c55e", "#3b82f6", "#eab308", "#ec4899", "#8b5cf6", "#06b6d4", "#f5f5f7"][i] }} />)}</div>
                    </div>
                  </div>
                  <div className="h-12 w-10 rounded-b-2xl bg-black/40" />
                </div>
              ) : product.family === "mac" ? (
                <div className="mx-auto w-full max-w-[440px]">
                  <div className="overflow-hidden rounded-t-2xl bg-black p-2 pb-0 shadow-2xl ring-1 ring-white/20">
                    <div className="flex h-56 flex-col items-center justify-center rounded-t-xl bg-[radial-gradient(ellipse_at_center,#312e81,#000_75%)] sm:h-64">
                      <p className="text-glow-pro text-5xl font-black">Pro</p>
                      <p className="mt-2 text-[12px] text-white/60">PROLED XDR · M6</p>
                    </div>
                  </div>
                  <div className="h-3 rounded-b-2xl bg-gradient-to-b from-[#3f3f46] to-[#18181b]" />
                  <div className="mx-auto h-1.5 w-24 rounded-b-lg bg-black/60" />
                </div>
              ) : (
                <div className="mx-auto h-72 w-36 rounded-[36px] bg-black/80 p-2 shadow-2xl ring-1 ring-white/25 sm:h-80 sm:w-40">
                  <div className="flex h-full flex-col overflow-hidden rounded-[28px] bg-gradient-to-b from-[#1e1b4b] via-[#312e81] to-black">
                    <div className="mx-auto mt-2 h-5 w-16 rounded-full bg-black" />
                    <p className="mt-8 text-2xl font-bold text-white">9:41</p>
                    <div className="mx-3 mt-3 space-y-1.5">
                      <div className="rounded-xl bg-white/15 p-2 text-left text-[10px] text-white">Messages · See you at Orchard?</div>
                      <div className="rounded-xl bg-white/10 p-2 text-left text-[10px] text-white/80">Calendar · Design review 10:00</div>
                    </div>
                  </div>
                </div>
              )}
              <p className="mt-4 text-[13px] text-white/70">{finish.name}{storage ? ` · ${storage.label}` : ""}</p>
            </div>
          </div>
          <div className="mt-4 grid grid-cols-3 gap-3 text-center text-[13px]">
            {[["Free delivery", "1–2 days islandwide"], ["Free engraving", "Emoji, initials, dates"], ["Free returns", "14-day no-questions"]].map(([t, d]) => (
              <div key={t} className="rounded-2xl bg-[#f5f5f7] p-3"><p className="font-semibold">{t}</p><p className="text-[#6e6e73]">{d}</p></div>
            ))}
          </div>
        </div>

        {/* Configurator */}
        <div>
          {product.badge && <p className="text-[14px] font-semibold text-[#b00020]">{product.badge}</p>}
          <h1 className="text-[32px] font-bold leading-tight tracking-tight sm:text-[40px]">Buy {product.name}</h1>
          <p className="mt-1 text-[17px] text-[#6e6e73]">{product.tagline}</p>
          <div className="mt-2 flex items-center gap-2"><Stars rating={product.rating} /><span className="text-[14px] text-[#6e6e73]">{product.rating} · {product.reviews.toLocaleString()} reviews (SG)</span></div>
          <p className="mt-4 text-[15px] leading-relaxed text-[#333]">{product.description}</p>
          {eduPricing && <p className="mt-3 inline-flex items-center gap-1.5 rounded-full bg-[#e8f3ff] px-3 py-1.5 text-[13px] font-medium text-[#0066cc]"><Sparkles className="h-3.5 w-3.5" /> Education pricing applied — 6% off</p>}

          <div className="mt-7">
            <h2 className="text-[17px] font-bold">Finish. <span className="font-normal text-[#6e6e73]">{finish.name}</span></h2>
            <div className="mt-3 flex gap-3" role="radiogroup" aria-label="Finish">
              {product.finishes.map((f) => (
                <button key={f.id} role="radio" aria-checked={finish.id === f.id} aria-label={f.name} onClick={() => setFinish(f)} className={cn("h-10 w-10 rounded-full ring-offset-2 transition", finish.id === f.id ? "ring-2 ring-[#0071e3]" : "ring-1 ring-black/15 hover:scale-105")} style={{ background: f.swatch }} />
              ))}
            </div>
          </div>

          {product.storages && (
            <div className="mt-7">
              <h2 className="text-[17px] font-bold">Storage. <span className="font-normal text-[#6e6e73]">{storage?.label}</span></h2>
              <div className="mt-3 grid grid-cols-2 gap-2" role="radiogroup" aria-label="Storage">
                {product.storages.map((s) => (
                  <button key={s.id} role="radio" aria-checked={storage?.id === s.id} onClick={() => setStorage(s)} className={cn("rounded-2xl border p-3.5 text-left transition", storage?.id === s.id ? "border-[#0071e3] bg-[#f0f7ff] shadow-sm" : "border-black/15 hover:border-black/40")}>
                    <span className="block font-semibold">{s.label}</span>
                    <span className="block text-[13px] text-[#6e6e73]">{s.delta === 0 ? "Included" : `+${SGD(s.delta)}`}</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          <div className="mt-7 rounded-2xl border border-black/10 p-4">
            <label className="flex cursor-pointer items-start gap-3">
              <input type="checkbox" checked={appleCare} onChange={(e) => setAppleCare(e.target.checked)} className="mt-1 h-4 w-4 accent-[#0071e3]" />
              <span><span className="flex items-center gap-1.5 font-semibold"><ShieldCheck className="h-4 w-4 text-[#0071e3]" /> AppleCare+ — {SGD(carePrice)}</span>
              <span className="block text-[13px] text-[#6e6e73]">Unlimited accidental-damage repairs, battery service & 24/7 priority support. 2 years.</span></span>
            </label>
          </div>

          <div className="mt-5">
            <label htmlFor="engrave" className="text-[17px] font-bold">Free engraving <span className="font-normal text-[#6e6e73] text-[14px]">— make it yours</span></label>
            <input id="engrave" value={engraving} onChange={(e) => setEngraving(e.target.value.slice(0, 30))} placeholder="e.g. For Mei ♥ 2026" className="mt-2 w-full rounded-2xl border border-black/15 px-4 py-3 text-[15px] outline-none focus:border-[#0071e3]" maxLength={30} />
          </div>

          <div className="mt-6">
            <h2 className="text-[17px] font-bold">How will you get it?</h2>
            <div className="mt-3 grid grid-cols-2 gap-2" role="radiogroup" aria-label="Fulfilment">
              <button role="radio" aria-checked={fulfilment === "delivery"} onClick={() => setFulfilment("delivery")} className={cn("rounded-2xl border p-4 text-left", fulfilment === "delivery" ? "border-[#0071e3] bg-[#f0f7ff]" : "border-black/15")}>
                <Truck className="h-5 w-5" /><span className="mt-1 block font-semibold">Delivery</span><span className="block text-[13px] text-[#6e6e73]">Free · Tomorrow, islandwide</span>
              </button>
              <button role="radio" aria-checked={fulfilment === "pickup"} onClick={() => setFulfilment("pickup")} className={cn("rounded-2xl border p-4 text-left", fulfilment === "pickup" ? "border-[#0071e3] bg-[#f0f7ff]" : "border-black/15")}>
                <MapPin className="h-5 w-5" /><span className="mt-1 block font-semibold">Apple Pickup</span><span className="block text-[13px] text-[#6e6e73]">Today · In-stock stores</span>
              </button>
            </div>
            {fulfilment === "pickup" && (
              <div className="mt-3 space-y-2">
                {SG_STORES.map((s) => (
                  <label key={s.id} className={cn("flex cursor-pointer items-center gap-3 rounded-2xl border p-3.5", pickup === s.id ? "border-[#0071e3] bg-[#f0f7ff]" : "border-black/10")}>
                    <input type="radio" name="store" checked={pickup === s.id} onChange={() => setPickup(s.id)} className="accent-[#0071e3]" />
                    <span><span className="block font-semibold text-[14px]">{s.name} — <span className="text-[#067c2b]">In stock</span></span><span className="block text-[13px] text-[#6e6e73]">{s.address} · {s.hours}</span></span>
                  </label>
                ))}
              </div>
            )}
          </div>

          <div className="mt-7 rounded-2xl bg-[#f5f5f7] p-5">
            <div className="flex items-center justify-between text-[15px]"><span>Unit {eduPricing && <s className="text-[#6e6e73]">{SGD(unit)}</s>}</span><span className="text-[22px] font-bold">{SGD(eduUnit + (appleCare ? carePrice : 0))}</span></div>
            <p className="text-[13px] text-[#6e6e73]">Incl. 9% GST ({SGD((eduUnit + (appleCare ? carePrice : 0)) - (eduUnit + (appleCare ? carePrice : 0)) / (1 + GST_RATE))}) · or {SGD(monthly)}/mo. × 24 at 0%</p>
            <div className="mt-3 flex items-center gap-3">
              <div className="flex items-center gap-2 rounded-full border border-black/15 bg-white px-3 py-2">
                <button aria-label="Decrease quantity" onClick={() => setQty(Math.max(1, qty - 1))}><Minus className="h-4 w-4" /></button>
                <span className="min-w-6 text-center font-semibold" aria-live="polite">{qty}</span>
                <button aria-label="Increase quantity" onClick={() => setQty(Math.min(5, qty + 1))}><Plus className="h-4 w-4" /></button>
              </div>
              <button
                onClick={() => addToBag({ productId: product.id, name: product.name, variant: `${finish.name} · ${storage?.label ?? "Standard"}${appleCare ? " · AppleCare+" : ""}${engraving ? ` · “${engraving}”` : ""}`, unitPrice: eduUnit + (appleCare ? carePrice : 0), imageGradient: product.gradient, meta: fulfilment === "pickup" ? `Pickup: ${SG_STORES.find((s) => s.id === pickup)?.name}` : "Free delivery" }, qty)}
                className="btn-apple-blue flex-1 py-3 text-[16px] font-medium"
              >
                Add to Bag — {SGD(total)}
              </button>
            </div>
            <p className="mt-2 flex items-center gap-1.5 text-[13px] text-[#6e6e73]"><CreditCard className="h-3.5 w-3.5" /> 0% instalments with DBS · UOB · OCBC · Atome</p>
          </div>

          <div className="mt-7">
            <h2 className="text-[19px] font-bold">Tech Specs</h2>
            <dl className="mt-3 divide-y divide-black/10 rounded-2xl border border-black/10">
              {product.specs.map((s) => (
                <div key={s.label} className="grid grid-cols-[140px_1fr] gap-3 px-4 py-3 text-[14px]">
                  <dt className="font-semibold">{s.label}</dt><dd className="text-[#333]">{s.value}</dd>
                </div>
              ))}
            </dl>
            <div className="mt-3 flex flex-wrap gap-2">
              {product.highlights.map((h) => <span key={h} className="inline-flex items-center gap-1 rounded-full bg-[#f5f5f7] px-3 py-1.5 text-[13px]"><Check className="h-3 w-3 text-[#067c2b]" /> {h}</span>)}
            </div>
          </div>
        </div>
      </div>

      {related.length > 0 && (
        <div className="border-t border-black/5 bg-[#f5f5f7] px-5 py-10">
          <div className="mx-auto max-w-[1200px]">
            <h2 className="text-[22px] font-bold">You may also like</h2>
            <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-3">
              {related.map((r) => (
                <button key={r.id} onClick={() => go({ name: "product", id: r.id })} className="rounded-2xl bg-white p-5 text-left shadow-sm hover:shadow-md">
                  <div className={cn("h-36 rounded-xl bg-gradient-to-br", r.gradient)} />
                  <p className="mt-3 font-bold">{r.name}</p>
                  <p className="text-[13px] text-[#6e6e73]">{r.tagline}</p>
                  <p className="mt-1 text-[14px] font-semibold">From {SGD(r.basePrice)}</p>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export function ComparePage() {
  const { go } = useShop();
  const [ids, setIds] = useState<string[]>(["iphone-18", "iphone-18-pro", "iphone-duo"]);
  const rows = useMemo(() => {
    const items = ids.map((id) => PRODUCTS.find((p) => p.id === id)!).filter(Boolean);
    const labels = Array.from(new Set(items.flatMap((p) => p.specs.map((s) => s.label))));
    return { items, labels };
  }, [ids]);

  return (
    <div className="bg-white">
      <div className="mx-auto max-w-[1100px] px-5 py-10">
        <h1 className="text-[36px] font-bold tracking-tight sm:text-[48px]">Compare iPhone models</h1>
        <p className="mt-1 text-[#6e6e73]">Prices include GST · Trade In credit deducted at checkout.</p>
        <div className="mt-5 flex flex-wrap gap-2">
          {(["iphone-18", "iphone-18-pro", "iphone-duo"] as const).map((id) => {
            const p = PRODUCTS.find((x) => x.id === id)!;
            const on = ids.includes(id);
            return (
              <button key={id} onClick={() => setIds((prev) => (on ? prev.filter((x) => x !== id) : [...prev, id].slice(-3)))} aria-pressed={on} className={cn("rounded-full border px-4 py-2 text-[14px]", on ? "border-[#0071e3] bg-[#0071e3] text-white" : "border-black/15")}>
                {p.name}
              </button>
            );
          })}
        </div>
        <div className="mt-6 overflow-x-auto rounded-2xl border border-black/10">
          <table className="w-full min-w-[640px] text-left text-[14px]">
            <thead>
              <tr className="bg-[#f5f5f7]">
                <th className="p-4 font-medium text-[#6e6e73]">Model</th>
                {rows.items.map((p: Product) => (
                  <th key={p.id} className="p-4">
                    <div className={cn("h-24 rounded-xl bg-gradient-to-br", p.gradient)} />
                    <p className="mt-2 text-[16px] font-bold">{p.name}</p>
                    <p className="text-[13px] font-normal text-[#6e6e73]">{p.tagline}</p>
                    <p className="mt-1 font-bold">{SGD(p.basePrice)}</p>
                    <button onClick={() => go({ name: "product", id: p.id })} className="btn-apple-blue mt-2 px-4 py-1.5 text-[13px]">Buy</button>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {rows.labels.map((label) => (
                <tr key={label} className="border-t border-black/5">
                  <th className="bg-[#fbfbfd] p-4 text-[13px] font-semibold">{label}</th>
                  {rows.items.map((p: Product) => (
                    <td key={p.id} className="p-4 text-[#333]">{p.specs.find((s) => s.label === label)?.value ?? "—"}</td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export function TradeInPage() {
  const { pushToast } = useShop();
  const [device, setDevice] = useState("iphone-15-pro");
  const [condition, setCondition] = useState<"excellent" | "good" | "fair">("excellent");
  const [age, setAge] = useState(1);
  const max = TRADE_IN_MAP[device].max;
  const factor = condition === "excellent" ? 1 : condition === "good" ? 0.78 : 0.55;
  const ageFactor = Math.max(0.6, 1 - age * 0.08);
  const estimate = Math.round(max * factor * ageFactor);

  return (
    <div className="bg-[#f5f5f7]">
      <div className="mx-auto grid max-w-[1100px] grid-cols-1 gap-6 px-5 py-10 lg:grid-cols-2">
        <div>
          <p className="flex items-center gap-2 text-[13px] font-semibold uppercase tracking-widest text-[#067c2b]"><RefreshCcw className="h-4 w-4" /> Apple Trade In</p>
          <h1 className="mt-2 text-[36px] font-bold leading-tight tracking-tight sm:text-[48px]">Turn yesterday’s device into tomorrow’s credit.</h1>
          <p className="mt-3 text-[17px] text-[#6e6e73]">Answer three questions. Get an instant estimate in Singapore dollars. Final value confirmed at pickup or by courier — data wiped to IMDA standards.</p>
          <div className="mt-6 space-y-5 rounded-2xl bg-white p-6 shadow-sm">
            <div>
              <label htmlFor="trade-device" className="text-[15px] font-bold">What are you trading in?</label>
              <select id="trade-device" value={device} onChange={(e) => setDevice(e.target.value)} className="mt-2 w-full rounded-xl border border-black/15 bg-white px-4 py-3">
                {Object.entries(TRADE_IN_MAP).map(([k, v]) => <option key={k} value={k}>{v.label} — up to {SGD(v.max)}</option>)}
              </select>
            </div>
            <div>
              <p className="text-[15px] font-bold" id="cond-label">Condition</p>
              <div className="mt-2 grid grid-cols-3 gap-2" role="radiogroup" aria-labelledby="cond-label">
                {(["excellent", "good", "fair"] as const).map((c) => (
                  <button key={c} role="radio" aria-checked={condition === c} onClick={() => setCondition(c)} className={cn("rounded-xl border p-3 text-[14px] capitalize", condition === c ? "border-[#0071e3] bg-[#f0f7ff] font-semibold" : "border-black/15")}>{c}</button>
                ))}
              </div>
              <p className="mt-1.5 text-[13px] text-[#6e6e73]">Excellent = flawless screen & battery ≥ 90%. Good = light marks. Fair = visible wear.</p>
            </div>
            <div>
              <label htmlFor="trade-age" className="flex justify-between text-[15px] font-bold">Device age <span className="font-normal text-[#6e6e73]">{age} yr</span></label>
              <input id="trade-age" type="range" min={0} max={5} value={age} onChange={(e) => setAge(Number(e.target.value))} className="apple-range mt-3 w-full" />
            </div>
          </div>
        </div>
        <div className="lg:sticky lg:top-24 lg:self-start">
          <div className="rounded-3xl bg-black p-8 text-white">
            <p className="flex items-center gap-2 text-[13px] uppercase tracking-widest text-white/50"><Calculator className="h-4 w-4" /> Instant estimate</p>
            <p className="mt-3 text-[64px] font-black leading-none tracking-tight">{SGD(estimate)}</p>
            <p className="mt-2 text-white/60 text-[14px]">Up to {SGD(max)} for {TRADE_IN_MAP[device].label} in excellent condition.</p>
            <div className="mt-4 h-2 overflow-hidden rounded-full bg-white/15"><div className="h-full rounded-full bg-gradient-to-r from-[#34d399] to-[#22d3ee] transition-all" style={{ width: `${Math.round((estimate / max) * 100)}%` }} /></div>
            <ul className="mt-5 space-y-2 text-[14px] text-white/80">
              <li className="flex gap-2"><Check className="h-4 w-4 text-[#34d399]" /> Deducted instantly at checkout or Apple Store</li>
              <li className="flex gap-2"><Check className="h-4 w-4 text-[#34d399]" /> Free courier pickup islandwide</li>
              <li className="flex gap-2"><Check className="h-4 w-4 text-[#34d399]" /> Certified data erasure + recycling if ineligible</li>
            </ul>
            <button onClick={() => pushToast({ title: "Trade-in reserved", body: `Estimate ${SGD(estimate)} locked for 14 days` })} className="mt-6 w-full rounded-full bg-white py-3 font-semibold text-black hover:bg-white/90">Reserve this estimate</button>
            <p className="mt-3 text-center text-[12px] text-white/40 flex items-center justify-center gap-1"><Info className="h-3 w-3" /> Final value confirmed after inspection. T&Cs apply.</p>
          </div>
        </div>
      </div>
    </div>
  );
}

export function AccessoriesPage() {
  const { addToBag, toggleWish, wishlist } = useShop();
  const [cat, setCat] = useState("All");
  const cats = ["All", ...Array.from(new Set(ACCESSORIES.map((a) => a.category)))];
  const items = ACCESSORIES.filter((a) => cat === "All" || a.category === cat);
  return (
    <div className="bg-[#f5f5f7]">
      <div className="mx-auto max-w-[1200px] px-5 py-10">
        <h1 className="text-[36px] font-bold tracking-tight sm:text-[48px]">Accessories</h1>
        <p className="text-[#6e6e73]">MagSafe, cases, keyboards, AirTag and more — all with free delivery.</p>
        <div className="no-scrollbar mt-4 flex gap-2 overflow-x-auto pb-1">
          {cats.map((c) => <button key={c} onClick={() => setCat(c)} aria-pressed={cat === c} className={cn("shrink-0 rounded-full px-4 py-2 text-[14px]", cat === c ? "bg-black text-white" : "bg-white shadow-sm")}>{c}</button>)}
        </div>
        <div className="mt-6 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {items.map((a) => (
            <article key={a.id} className="rounded-2xl bg-white p-6 shadow-sm">
              {a.tag && <span className="text-[12px] font-semibold text-[#b00020]">{a.tag}</span>}
              <div className="flex h-36 items-center justify-center rounded-xl bg-gradient-to-br from-[#f5f5f7] to-[#e2e8f0]" aria-hidden="true">
                <span className="flex h-16 w-16 items-center justify-center rounded-2xl bg-white text-[22px] font-black shadow">{a.name[0]}</span>
              </div>
              <div className="mt-3 flex items-start justify-between gap-2">
                <h2 className="font-bold leading-tight">{a.name}</h2>
                <button aria-label={`Save ${a.name}`} onClick={() => toggleWish(a.id)}><Heart className={cn("h-4 w-4", wishlist.includes(a.id) ? "fill-red-500 text-red-500" : "text-[#6e6e73]")} /></button>
              </div>
              <p className="text-[13px] text-[#6e6e73]">{a.blurb}</p>
              <div className="mt-2 flex gap-1.5">{a.colors.map((c) => <span key={c} className="h-4 w-4 rounded-full ring-1 ring-black/15" style={{ background: c }} />)}</div>
              <div className="mt-3 flex items-center justify-between">
                <p className="font-bold">{SGD(a.price)}</p>
                <button onClick={() => addToBag({ productId: a.id, name: a.name, variant: a.category, unitPrice: a.price, imageGradient: "from-[#e2e8f0] to-[#94a3b8]" })} className="btn-apple-blue px-5 py-1.5 text-[14px]">Add</button>
              </div>
            </article>
          ))}
        </div>
      </div>
    </div>
  );
}

export function EntertainmentPage() {
  const { pushToast } = useShop();
  return (
    <div className="bg-black text-white">
      <div className="mx-auto max-w-[1100px] px-5 py-14 text-center">
        <p className="text-[13px] uppercase tracking-[0.2em] text-white/50">Apple Services · Singapore</p>
        <h1 className="display-section mx-auto mt-2 max-w-2xl">Endless entertainment. One subscription away.</h1>
        <div className="mx-auto mt-8 grid max-w-3xl grid-cols-1 gap-4 text-left sm:grid-cols-2">
          {[
            ["Apple One Premier", "Music + TV+ + Arcade + Fitness+ + News+ + 2TB iCloud+", "S$33.95/mo.", "Save S$12/mo."],
            ["Student Bundle", "Music + TV+ with UNiDAYS verification (SG unis)", "S$7.98/mo.", "50% off"],
          ].map(([t, d, p, s]) => (
            <div key={t} className="rounded-2xl bg-white/10 p-6 backdrop-blur">
              <p className="font-bold text-[19px]">{t}</p>
              <p className="text-white/60 text-[14px]">{d}</p>
              <p className="mt-2 text-[22px] font-bold">{p} <span className="text-[13px] font-normal text-[#4ade80]">{s}</span></p>
              <button onClick={() => pushToast({ title: "Trial started", body: `${t} — 1 month free` })} className="mt-3 w-full rounded-full bg-white py-2.5 text-black font-semibold">Try 1 month free</button>
            </div>
          ))}
        </div>
        <p className="mt-6 text-[13px] text-white/40">Prices in SGD, incl. GST. Cancel anytime in Settings.</p>
      </div>
    </div>
  );
}
