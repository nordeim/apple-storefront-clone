import { useMemo, useState } from "react";
import { MapPin, Phone, Clock, Search, ChevronRight, MessageCircle, Wrench, ShieldCheck, CreditCard, Package, CheckCircle2, ArrowRight, Loader2 } from "lucide-react";
import { SG_STORES, SGD } from "../data/catalog";
import { useShop } from "../lib/shop";
import { cn } from "../utils/cn";

export function SupportPage() {
  const { pushToast, go } = useShop();
  const [q, setQ] = useState("");
  const topics = [
    { t: "iPhone", d: "Battery, display, Apple Intelligence", icon: "◍" },
    { t: "Mac", d: "macOS Tahoe, M6 optimisation", icon: "▣" },
    { t: "iPad", d: "Pencil, keyboards, Stage Manager", icon: "▤" },
    { t: "Watch", d: "Health data, bands, pairing", icon: "◉" },
    { t: "AirPods", d: "ANC, fit, Live Translation", icon: "♪" },
    { t: "Apple ID & iCloud+", d: "Storage, family, security", icon: "☁" },
  ];
  const filtered = topics.filter((x) => x.t.toLowerCase().includes(q.toLowerCase()) || x.d.toLowerCase().includes(q.toLowerCase()));
  return (
    <div className="bg-white">
      <div className="mx-auto max-w-[900px] px-5 py-12 text-center">
        <h1 className="text-[36px] font-bold tracking-tight sm:text-[48px]">Apple Support Singapore</h1>
        <p className="mt-2 text-[#6e6e73]">1800 692 7753 · Mon–Sun 9:00–21:00 SGT · 中文 · Melayu · தமிழ்</p>
        <div className="mx-auto mt-6 flex max-w-xl items-center gap-2 rounded-full border border-black/15 px-5 py-3 shadow-sm focus-within:border-[#0071e3]">
          <Search className="h-4 w-4 text-[#6e6e73]" />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search support — e.g. battery, trade in, warranty" className="w-full outline-none text-[15px]" aria-label="Search support" />
        </div>
        <div className="mt-8 grid grid-cols-2 gap-3 text-left sm:grid-cols-3">
          {filtered.map((x) => (
            <button key={x.t} onClick={() => pushToast({ title: x.t, body: "Opening guided troubleshooting…" })} className="rounded-2xl border border-black/10 p-5 text-left hover:border-[#0071e3] hover:shadow-md">
              <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#f5f5f7] text-xl">{x.icon}</span>
              <p className="mt-3 font-bold">{x.t}</p>
              <p className="text-[13px] text-[#6e6e73]">{x.d}</p>
            </button>
          ))}
        </div>
        <div className="mt-8 grid grid-cols-1 gap-3 sm:grid-cols-3">
          {(
            [
              ["Chat with a Specialist", "Avg. wait 2 min", MessageCircle],
              ["Book Genius Bar", "Orchard · MBS · Jewel", Wrench],
              ["Check repair status", "Track by case ID", Package],
            ] as [string, string, typeof MessageCircle][]
          ).map(([t, d, Icon]) => (
            <button key={t} onClick={() => pushToast({ title: t, body: "Connecting you…" })} className="flex items-center gap-3 rounded-2xl bg-[#f5f5f7] p-4 text-left">
              <Icon className="h-5 w-5 text-[#0071e3]" />
              <span><span className="block font-semibold text-[14px]">{t}</span><span className="block text-[13px] text-[#6e6e73]">{d}</span></span>
            </button>
          ))}
        </div>
        <div className="mt-8 rounded-2xl bg-black p-7 text-left text-white sm:flex sm:items-center sm:justify-between">
          <div><p className="text-[20px] font-bold">AppleCare+ from {SGD(149)}</p><p className="text-white/60 text-[14px]">Accidental damage, battery & priority support — 2 years, SG-wide.</p></div>
          <button onClick={() => go({ name: "store" })} className="mt-4 rounded-full bg-white px-6 py-2.5 font-semibold text-black sm:mt-0">Add at checkout</button>
        </div>
      </div>
    </div>
  );
}

export function StoresPage() {
  const { pushToast } = useShop();
  const [query, setQuery] = useState("");
  const stores = SG_STORES.filter((s) => (s.name + s.address).toLowerCase().includes(query.toLowerCase()));
  return (
    <div className="bg-[#f5f5f7]">
      <div className="mx-auto max-w-[1100px] px-5 py-10">
        <h1 className="text-[36px] font-bold tracking-tight sm:text-[48px]">Apple Store <span className="text-[#6e6e73]">Singapore</span></h1>
        <div className="mt-4 flex max-w-md items-center gap-2 rounded-full bg-white px-5 py-3 shadow-sm">
          <Search className="h-4 w-4 text-[#6e6e73]" />
          <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search stores — Orchard, Marina Bay, Changi" className="w-full bg-transparent text-[15px] outline-none" aria-label="Search stores" />
        </div>
        <div className="mt-6 grid grid-cols-1 gap-4 md:grid-cols-3">
          {stores.map((s, i) => (
            <article key={s.id} className="overflow-hidden rounded-2xl bg-white shadow-sm">
              <div className={cn("flex h-40 items-end p-5 text-white", i === 0 ? "bg-gradient-to-br from-[#1e293b] via-[#334155] to-[#94a3b8]" : i === 1 ? "bg-gradient-to-br from-[#0c4a6e] via-[#0284c7] to-[#7dd3fc]" : "bg-gradient-to-br from-[#14532d] via-[#16a34a] to-[#bef264]")} aria-hidden="true">
                <p className="text-[22px] font-black leading-tight">{s.name.replace("Apple ", "")}</p>
              </div>
              <div className="space-y-2 p-5 text-[14px]">
                <p className="flex gap-2"><MapPin className="mt-0.5 h-4 w-4 shrink-0 text-[#6e6e73]" /> {s.address}</p>
                <p className="flex gap-2"><Clock className="mt-0.5 h-4 w-4 shrink-0 text-[#6e6e73]" /> {s.hours}</p>
                <p className="flex gap-2"><Phone className="mt-0.5 h-4 w-4 shrink-0 text-[#6e6e73]" /> {s.phone} · {s.mrt}</p>
                <p className="inline-flex items-center gap-1.5 rounded-full bg-[#e6f4ea] px-3 py-1 text-[13px] font-medium text-[#067c2b]"><CheckCircle2 className="h-3.5 w-3.5" /> In stock — {s.stockNote}</p>
                <div className="flex gap-2 pt-2">
                  <button onClick={() => pushToast({ title: "Session booked", body: `${s.name} — Today 15:30` })} className="btn-apple-blue flex-1 py-2 text-[14px]">Book a session</button>
                  <button onClick={() => pushToast({ title: "Directions", body: s.mrt })} className="btn-apple-outline flex-1 py-2 text-[14px]">Directions</button>
                </div>
              </div>
            </article>
          ))}
        </div>
        <div className="mt-6 rounded-2xl bg-white p-6 shadow-sm">
          <h2 className="font-bold text-[19px]">Today at Apple — Singapore</h2>
          <div className="mt-3 grid grid-cols-1 gap-3 sm:grid-cols-3 text-[14px]">
            {[["Sketch with iPad + Pencil Pro", "Orchard · Sat 11:00"], ["Shoot ProRAW on iPhone 18 Pro", "MBS · Sun 14:00"], ["Code your first SwiftUI app", "Jewel · Sat 16:00"]].map(([t, d]) => (
              <button key={t} onClick={() => pushToast({ title: "Registered", body: t })} className="rounded-xl bg-[#f5f5f7] p-4 text-left hover:bg-[#ececf0]">
                <p className="font-semibold">{t}</p><p className="text-[#6e6e73] text-[13px]">{d} · Free</p>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

type CheckoutStep = 0 | 1 | 2;

export function CheckoutPage() {
  const { bag, subtotal, gst, updateQty, removeLine, promo, applyPromo, placeOrder, go, eduPricing } = useShop();
  const [step, setStep] = useState<CheckoutStep>(0);
  const [code, setCode] = useState("");
  const [form, setForm] = useState({ name: "", email: "", phone: "", postal: "", address: "", unit: "", card: "", expiry: "", cvc: "", method: "card" as "card" | "paynow" | "instalment" });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [placing, setPlacing] = useState(false);
  const deliveryFee = subtotal >= 200 || subtotal === 0 ? 0 : 12;
  const promoOff = promo ? Math.min(80, subtotal * 0.05) : 0;
  const total = Math.max(0, subtotal - promoOff + deliveryFee);

  const set = (k: keyof typeof form, v: string) => {
    setForm((f) => ({ ...f, [k]: v }));
    setErrors((e) => ({ ...e, [k]: "" }));
  };

  const validate = () => {
    const e: Record<string, string> = {};
    if (form.name.trim().length < 2) e.name = "Enter your full name.";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) e.email = "Enter a valid email for your GST invoice.";
    if (!/^[689]\d{7}$/.test(form.phone.replace(/\s/g, ""))) e.phone = "Enter an 8-digit SG mobile (e.g. 8123 4567).";
    if (!/^\d{6}$/.test(form.postal)) e.postal = "6-digit postal code required.";
    if (form.address.trim().length < 5) e.address = "Enter street + block.";
    if (form.method === "card") {
      if (form.card.replace(/\s/g, "").length < 15) e.card = "Enter card number.";
      if (!/^\d{2}\/\d{2}$/.test(form.expiry)) e.expiry = "MM/YY.";
      if (form.cvc.length < 3) e.cvc = "3–4 digits.";
    }
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const confirm = async () => {
    if (!validate()) return;
    setPlacing(true);
    await new Promise((r) => setTimeout(r, 1400));
    const id = placeOrder(form.email);
    setPlacing(false);
    go({ name: "order-success", orderId: id });
  };

  const eta = useMemo(() => {
    const d = new Date(Date.now() + 2 * 864e5);
    return d.toLocaleDateString("en-SG", { weekday: "long", day: "numeric", month: "long" });
  }, []);

  if (bag.length === 0 && step !== 2) {
    return (
      <div className="mx-auto max-w-xl px-5 py-20 text-center">
        <Package className="mx-auto h-12 w-12 text-[#d2d2d7]" />
        <h1 className="mt-4 text-[32px] font-bold">Your bag is empty</h1>
        <p className="text-[#6e6e73]">Checkout needs at least one item.</p>
        <button onClick={() => go({ name: "store" })} className="btn-apple-blue mt-5 px-8 py-3">Back to Store</button>
      </div>
    );
  }

  return (
    <div className="bg-[#f5f5f7]">
      <div className="mx-auto max-w-[1080px] px-5 py-10">
        <h1 className="text-[32px] font-bold tracking-tight sm:text-[40px]">Check Out</h1>
        <ol className="mt-4 flex items-center gap-2 text-[13px]" aria-label="Checkout progress">
          {(["Bag & promo", "Details & payment", "Review"] as const).map((label, i) => (
            <li key={label} className="flex items-center gap-2">
              <span className={cn("flex h-6 w-6 items-center justify-center rounded-full text-[12px] font-bold", step >= i ? "bg-black text-white" : "bg-black/10 text-[#6e6e73]")}>{i + 1}</span>
              <span className={step === i ? "font-semibold" : "text-[#6e6e73]"}>{label}</span>
              {i < 2 && <ChevronRight className="h-3.5 w-3.5 text-black/30" />}
            </li>
          ))}
        </ol>

        <div className="mt-6 grid grid-cols-1 gap-5 lg:grid-cols-[1fr_360px]">
          <div className="min-w-0">
            {step === 0 && (
              <section className="rounded-2xl bg-white p-6 shadow-sm" aria-label="Review bag">
                <h2 className="text-[19px] font-bold">1 · Review your bag</h2>
                <ul className="mt-4 divide-y divide-black/10">
                  {bag.map((l) => (
                    <li key={l.key} className="flex gap-4 py-4">
                      <div className={cn("h-16 w-16 shrink-0 rounded-xl bg-gradient-to-br", l.imageGradient)} />
                      <div className="flex-1">
                        <p className="font-semibold text-[15px]">{l.name}</p>
                        <p className="text-[13px] text-[#6e6e73]">{l.variant}</p>
                        <div className="mt-2 flex items-center justify-between">
                          <div className="flex items-center gap-2 rounded-full border border-black/10 px-2 py-0.5 text-[13px]">
                            <button aria-label="Decrease" onClick={() => updateQty(l.key, l.qty - 1)} className="px-1">−</button>
                            <span className="font-semibold">{l.qty}</span>
                            <button aria-label="Increase" onClick={() => updateQty(l.key, l.qty + 1)} className="px-1">+</button>
                          </div>
                          <p className="font-semibold">{SGD(l.unitPrice * l.qty)}</p>
                        </div>
                      </div>
                      <button onClick={() => removeLine(l.key)} className="text-[13px] text-[#6e6e73] hover:text-red-600">Remove</button>
                    </li>
                  ))}
                </ul>
                <div className="mt-4 flex gap-2">
                  <input value={code} onChange={(e) => setCode(e.target.value)} placeholder="Promo code — try HELLOSG10" className="flex-1 rounded-xl border border-black/15 px-4 py-2.5 text-[14px] outline-none focus:border-[#0071e3]" aria-label="Promo code" />
                  <button onClick={() => applyPromo(code)} className="rounded-xl bg-black px-5 py-2.5 text-[14px] font-medium text-white">Apply</button>
                </div>
                {promo && <p className="mt-2 text-[13px] text-[#067c2b]">✓ {promo} applied — 5% off (capped at {SGD(80)}).</p>}
                {eduPricing && <p className="mt-1 text-[13px] text-[#0066cc]">✓ Education pricing (6% off) applied.</p>}
                <button onClick={() => setStep(1)} className="btn-apple-blue mt-5 w-full py-3 font-medium">Continue to details</button>
              </section>
            )}

            {step === 1 && (
              <section className="space-y-4" aria-label="Details and payment">
                <div className="rounded-2xl bg-white p-6 shadow-sm">
                  <h2 className="text-[19px] font-bold">2 · Contact & delivery (Singapore)</h2>
                  <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2">
                    {(
                      [
                        ["name", "Full name", "Tan Mei Ling", "text"],
                        ["email", "Email (GST invoice)", "mei@example.sg", "email"],
                        ["phone", "Mobile", "8123 4567", "tel"],
                        ["postal", "Postal code", "238857", "text"],
                      ] as const
                    ).map(([k, label, ph, type]) => (
                      <label key={k} className="block text-[13px] font-medium">
                        {label}
                        <input type={type} value={form[k]} onChange={(e) => set(k, e.target.value)} placeholder={ph} className={cn("mt-1 w-full rounded-xl border px-4 py-2.5 text-[15px] outline-none", errors[k] ? "border-red-500" : "border-black/15 focus:border-[#0071e3]")} aria-invalid={!!errors[k]} />
                        {errors[k] && <span className="mt-1 block font-normal text-red-600">{errors[k]}</span>}
                      </label>
                    ))}
                    <label className="block text-[13px] font-medium sm:col-span-2">Street + block
                      <input value={form.address} onChange={(e) => set("address", e.target.value)} placeholder="270 Orchard Road" className={cn("mt-1 w-full rounded-xl border px-4 py-2.5 text-[15px] outline-none", errors.address ? "border-red-500" : "border-black/15 focus:border-[#0071e3]")} />
                      {errors.address && <span className="font-normal text-red-600">{errors.address}</span>}
                    </label>
                    <label className="block text-[13px] font-medium">Unit / floor (optional)
                      <input value={form.unit} onChange={(e) => set("unit", e.target.value)} placeholder="#08-01" className="mt-1 w-full rounded-xl border border-black/15 px-4 py-2.5 text-[15px] outline-none focus:border-[#0071e3]" />
                    </label>
                  </div>
                </div>
                <div className="rounded-2xl bg-white p-6 shadow-sm">
                  <h3 className="text-[17px] font-bold">Payment</h3>
                  <div className="mt-3 grid grid-cols-3 gap-2" role="radiogroup" aria-label="Payment method">
                    {([["card", "Card"], ["paynow", "PayNow"], ["instalment", "0% Instal."]] as const).map(([v, l]) => (
                      <button key={v} role="radio" aria-checked={form.method === v} onClick={() => set("method", v)} className={cn("rounded-xl border p-3 text-[14px]", form.method === v ? "border-[#0071e3] bg-[#f0f7ff] font-semibold" : "border-black/15")}>{l}</button>
                    ))}
                  </div>
                  {form.method === "card" ? (
                    <div className="mt-3 grid grid-cols-1 gap-3 sm:grid-cols-[1fr_120px_100px]">
                      <label className="block text-[13px] font-medium">Card number<input inputMode="numeric" value={form.card} onChange={(e) => set("card", e.target.value)} placeholder="4111 1111 1111 1111" className={cn("mt-1 w-full rounded-xl border px-4 py-2.5", errors.card ? "border-red-500" : "border-black/15")} />{errors.card && <span className="text-red-600 font-normal">{errors.card}</span>}</label>
                      <label className="block text-[13px] font-medium">Expiry<input value={form.expiry} onChange={(e) => set("expiry", e.target.value)} placeholder="08/28" className={cn("mt-1 w-full rounded-xl border px-4 py-2.5", errors.expiry ? "border-red-500" : "border-black/15")} />{errors.expiry && <span className="text-red-600 font-normal">{errors.expiry}</span>}</label>
                      <label className="block text-[13px] font-medium">CVC<input inputMode="numeric" value={form.cvc} onChange={(e) => set("cvc", e.target.value)} placeholder="123" className={cn("mt-1 w-full rounded-xl border px-4 py-2.5", errors.cvc ? "border-red-500" : "border-black/15")} />{errors.cvc && <span className="text-red-600 font-normal">{errors.cvc}</span>}</label>
                    </div>
                  ) : form.method === "paynow" ? (
                    <p className="mt-3 rounded-xl bg-[#f5f5f7] p-4 text-[14px]">You’ll receive a PayNow QR to <strong>UEN 201234567K</strong> after placing your order. Stock reserved for 24 hours.</p>
                  ) : (
                    <p className="mt-3 rounded-xl bg-[#f5f5f7] p-4 text-[14px] flex gap-2"><CreditCard className="h-4 w-4 mt-0.5" /> Split into 12/24/36 months at 0% with DBS, UOB, OCBC or Atome. ID verification at delivery.</p>
                  )}
                  <div className="mt-4 flex gap-2">
                    <button onClick={() => setStep(0)} className="flex-1 rounded-full border border-black/15 py-3 text-[15px]">Back</button>
                    <button onClick={() => { if (validate()) setStep(2); else window.scrollTo({ top: 0, behavior: "smooth" }); }} className="btn-apple-blue flex-[2] py-3 font-medium">Review order</button>
                  </div>
                </div>
              </section>
            )}

            {step === 2 && (
              <section className="rounded-2xl bg-white p-6 shadow-sm" aria-label="Review and place order">
                <h2 className="text-[19px] font-bold">3 · Review & place order</h2>
                <div className="mt-4 rounded-xl bg-[#f5f5f7] p-4 text-[14px]">
                  <p className="font-semibold">{form.name} · {form.phone}</p>
                  <p className="text-[#6e6e73]">{form.address}{form.unit ? `, ${form.unit}` : ""}, Singapore {form.postal}</p>
                  <p className="text-[#6e6e73]">{form.email} · Pay: {form.method === "card" ? `Card •••• ${form.card.slice(-4)}` : form.method === "paynow" ? "PayNow" : "0% Instalments"}</p>
                  <p className="mt-1 flex items-center gap-1.5 text-[#067c2b]"><ShieldCheck className="h-4 w-4" /> Estimated delivery: {eta} · GST invoice emailed</p>
                </div>
                <button onClick={() => setStep(1)} className="mt-3 text-[14px] text-[#0066cc] hover:underline">Edit details</button>
                <button disabled={placing} onClick={confirm} className="btn-apple-blue mt-4 flex w-full items-center justify-center gap-2 py-3.5 text-[16px] font-medium disabled:opacity-60">
                  {placing && <Loader2 className="h-4 w-4 animate-spin" />} {placing ? "Placing your order…" : `Place order — ${SGD(total)}`}
                </button>
                <p className="mt-2 text-center text-[12px] text-[#6e6e73]">By placing this order you agree to Apple SG sales terms. 14-day returns.</p>
              </section>
            )}
          </div>

          <aside className="lg:sticky lg:top-24 lg:self-start" aria-label="Order summary">
            <div className="rounded-2xl bg-white p-6 shadow-sm">
              <h2 className="text-[17px] font-bold">Order summary</h2>
              <dl className="mt-3 space-y-2 text-[14px]">
                <div className="flex justify-between"><dt className="text-[#6e6e73]">Subtotal (incl. GST)</dt><dd className="font-medium">{SGD(subtotal)}</dd></div>
                <div className="flex justify-between"><dt className="text-[#6e6e73]">GST portion (9%)</dt><dd>{SGD(gst)}</dd></div>
                <div className="flex justify-between"><dt className="text-[#6e6e73]">Delivery</dt><dd className={deliveryFee === 0 ? "text-[#067c2b] font-medium" : ""}>{deliveryFee === 0 ? "Free" : SGD(deliveryFee)}</dd></div>
                {promoOff > 0 && <div className="flex justify-between text-[#067c2b]"><dt>Promo {promo}</dt><dd>−{SGD(promoOff)}</dd></div>}
                <div className="flex justify-between border-t border-black/10 pt-3 text-[17px] font-bold"><dt>Total</dt><dd>{SGD(total)}</dd></div>
              </dl>
              <p className="mt-2 text-[12px] text-[#6e6e73]">or {SGD(total / 12)}/mo. × 12 at 0% · {SGD(total / 24)}/mo. × 24</p>
              <p className="mt-3 flex items-center gap-1.5 text-[13px] text-[#6e6e73]"><ShieldCheck className="h-4 w-4" /> 256-bit encrypted · PDPA compliant · No data stored</p>
            </div>
          </aside>
        </div>
      </div>
    </div>
  );
}

export function OrderSuccess({ orderId }: { orderId: string }) {
  const { lastOrder, go } = useShop();
  return (
    <div className="bg-white">
      <div className="mx-auto max-w-xl px-5 py-16 text-center">
        <CheckCircle2 className="mx-auto h-16 w-16 text-[#067c2b]" />
        <h1 className="mt-4 text-[36px] font-bold tracking-tight">Thank you. Order confirmed.</h1>
        <p className="mt-2 text-[17px] text-[#6e6e73]">Order <strong className="text-black">{orderId}</strong>{lastOrder ? <> · {SGD(lastOrder.total)}</> : null}</p>
        <div className="mt-6 rounded-2xl bg-[#f5f5f7] p-5 text-left text-[14px]">
          <p className="font-bold">What happens next</p>
          <ol className="mt-2 space-y-2 text-[#333]">
            <li className="flex gap-2"><span className="font-bold">1.</span> GST invoice + tracking sent to {lastOrder?.email ?? "your email"} within 5 minutes.</li>
            <li className="flex gap-2"><span className="font-bold">2.</span> Courier pickup today — SMS updates from Ninja Van / SingPost.</li>
            <li className="flex gap-2"><span className="font-bold">3.</span> 14-day free returns at any SG Apple Store.</li>
          </ol>
        </div>
        <div className="mt-6 flex gap-2">
          <button onClick={() => go({ name: "stores" })} className="btn-apple-outline flex-1 py-3">Track in Store <ArrowRight className="ml-1 inline h-4 w-4" /></button>
          <button onClick={() => go({ name: "store" })} className="btn-apple-blue flex-1 py-3">Continue shopping</button>
        </div>
      </div>
    </div>
  );
}

export function SpecialistWidget() {
  const { pushToast } = useShop();
  const [open, setOpen] = useState(false);
  const [msg, setMsg] = useState("");
  const [thread, setThread] = useState<{ me: boolean; text: string }[]>([{ me: false, text: "Hi, I’m Maya from Apple Singapore. iPhone, Mac or Trade In — what can I help with?" }]);
  const send = () => {
    if (!msg.trim()) return;
    const q = msg.trim();
    setThread((t) => [...t, { me: true, text: q }]);
    setMsg("");
    setTimeout(() => {
      const reply = /trade/i.test(q)
        ? "Trade In runs S$80–S$1,150 depending on model and condition. Try the estimator — it takes 30 seconds."
        : /deliver|pickup|orchard|mbs|jewel/i.test(q)
        ? "Delivery is free islandwide (1–2 days). In-stock pickup today at Orchard, Marina Bay Sands and Jewel."
        : /instal|pay|price|gst|student|edu/i.test(q)
        ? "All prices include 9% GST. Students save ~6% with education pricing, plus 0% instalments over 12/24/36 mo."
        : "Got it — a Specialist will follow up by email shortly. Meanwhile, free delivery and 14-day returns apply to everything.";
      setThread((t) => [...t, { me: false, text: reply }]);
    }, 700);
  };
  return (
    <div className="fixed bottom-5 right-5 z-[60]">
      {open && (
        <div className="mb-3 flex h-[420px] w-[320px] flex-col overflow-hidden rounded-2xl border border-black/10 bg-white shadow-2xl" role="dialog" aria-label="Chat with a Specialist">
          <div className="bg-black p-4 text-white"><p className="font-bold text-[15px]">Specialist Maya · SG</p><p className="text-[12px] text-white/60 flex items-center gap-1.5"><span className="h-2 w-2 rounded-full bg-[#4ade80]" /> Online · replies instantly</p></div>
          <div className="flex-1 space-y-2 overflow-y-auto p-4 text-[14px]">
            {thread.map((m, i) => (
              <p key={i} className={cn("max-w-[85%] rounded-2xl px-3.5 py-2.5", m.me ? "ml-auto bg-[#0071e3] text-white" : "bg-[#f5f5f7]")}>{m.text}</p>
            ))}
          </div>
          <form className="flex gap-2 border-t border-black/10 p-3" onSubmit={(e) => { e.preventDefault(); send(); }}>
            <input value={msg} onChange={(e) => setMsg(e.target.value)} placeholder="Ask about pricing, pickup…" className="flex-1 rounded-full bg-[#f5f5f7] px-4 py-2.5 text-[14px] outline-none" aria-label="Message specialist" />
            <button type="submit" aria-label="Send" className="rounded-full bg-[#0071e3] p-2.5 text-white"><ArrowRight className="h-4 w-4" /></button>
          </form>
        </div>
      )}
      <button onClick={() => (open ? setOpen(false) : (setOpen(true), pushToast({ title: "Specialist online", body: "Maya typically replies in seconds" })))} aria-label={open ? "Close chat" : "Chat with a Specialist"} className="flex h-14 w-14 items-center justify-center rounded-full bg-black text-white shadow-2xl transition hover:scale-105">
        <MessageCircle className="h-6 w-6" />
      </button>
    </div>
  );
}
