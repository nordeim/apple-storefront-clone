import { useEffect, useRef, useState } from "react";
import { Search, ShoppingBag, Menu, X, ChevronRight, Truck, GraduationCap, MapPin, Trash2, Minus, Plus, ArrowRight } from "lucide-react";
import { NAV_ITEMS, searchCatalog, SGD } from "../data/catalog";
import { useShop } from "../lib/shop";
import { cn } from "../utils/cn";

export function AppleMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 384 512" className={className} fill="currentColor" aria-hidden="true">
      <path d="M318.7 268.7c-.2-36.7 16.4-64.4 50-84.8-18.8-26.9-47.2-41.7-84.7-44.6-35.5-2.8-74.3 20.7-88.5 20.7-15 0-49.4-19.7-76.4-19.7C63.3 141.2 4 184.8 4 273.5q0 39.3 14.4 81.2c12.8 36.7 59 126.7 107.2 125.2 25.2-.6 43-17.9 75.8-17.9 31.8 0 48.3 17.9 76.4 17.9 48.6-.7 90.4-82.5 102.6-119.3-65.2-30.7-61.7-90-61.7-91.9zm-56.6-164.2c27.3-32.4 24.8-61.9 24-72.5-24.1 1.4-52 16.4-67.9 34.9-17.5 19.8-27.8 44.3-25.6 71.9 26.1 2 49.9-11.4 69.5-34.3z" />
    </svg>
  );
}

export default function GlobalNav() {
  const { go, view, bag, bagCount, subtotal, updateQty, removeLine, setSearchOpen, searchOpen, bagOpen, setBagOpen, eduPricing, setEduPricing } = useShop();
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [q, setQ] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);
  const results = searchCatalog(q);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    if (searchOpen) {
      setQ("");
      setTimeout(() => inputRef.current?.focus(), 60);
    }
  }, [searchOpen]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setSearchOpen(false);
        setBagOpen(false);
        setMobileOpen(false);
      }
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setSearchOpen(true);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [setSearchOpen, setBagOpen]);

  const isActive = (id: string) =>
    (view.name === "category" && view.family === id) ||
    (view.name === "home" && id === "store" ? false : false) ||
    (id === "store" && view.name === "store");

  return (
    <>
      <a href="#main" className="skip-link">Skip to main content</a>
      {/* Promo ribbon */}
      <div className="relative z-[60] bg-[#f5f5f7] px-4 py-2 text-center text-[12px] leading-snug text-[#1d1d1f]">
        <p className="mx-auto max-w-3xl">
          Shop online and get Specialist help, free delivery and more. Get in-stock items with Apple Pickup.{" "}
          <button onClick={() => go({ name: "store" })} className="text-[#0066cc] hover:underline">Shop now ›</button>
          <span className="mx-2 hidden sm:inline text-[#d2d2d7]">|</span>
          <span className="hidden sm:inline">Get S$80–S$1,150 in credit with Trade In.</span>
        </p>
      </div>

      {/* Global nav */}
      <header className={cn("sticky top-0 z-50 apple-nav-blur text-[#f5f5f7] transition-shadow", scrolled && "shadow-[0_1px_0_rgba(255,255,255,0.08),0_12px_32px_rgba(0,0,0,0.28)]")}>
        <nav aria-label="Global" className="mx-auto flex h-11 max-w-[1024px] items-center justify-between gap-1 px-4 text-[12px]">
          <button aria-label="Apple home" onClick={() => go({ name: "home" })} className="rounded p-1 opacity-90 transition hover:opacity-100">
            <AppleMark className="h-[17px] w-[14px]" />
          </button>
          <div className="hidden items-center gap-7 lg:flex">
            {NAV_ITEMS.map((n) => (
              <button
                key={n.id}
                onClick={() => {
                  if (n.id === "support") go({ name: "support" });
                  else if (n.id === "entertainment") go({ name: "entertainment" });
                  else if (n.id === "accessories") go({ name: "accessories" });
                  else if (n.id === "store") go({ name: "store" });
                  else go({ name: "category", family: n.id });
                }}
                className={cn("opacity-80 transition hover:opacity-100", isActive(n.id) && "opacity-100 underline underline-offset-8 decoration-white/60")}
              >
                {n.label}
              </button>
            ))}
          </div>
          <div className="flex items-center gap-4">
            <button aria-label="Search (⌘K)" onClick={() => setSearchOpen(true)} className="rounded p-1 opacity-80 hover:opacity-100">
              <Search className="h-[15px] w-[15px]" />
            </button>
            <button aria-label={`Shopping bag, ${bagCount} items`} onClick={() => setBagOpen(true)} className="relative rounded p-1 opacity-80 hover:opacity-100">
              <ShoppingBag className="h-[15px] w-[15px]" />
              {bagCount > 0 && (
                <span className="absolute -right-1 -top-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-[#0071e3] px-1 text-[10px] font-semibold text-white">{bagCount}</span>
              )}
            </button>
            <button aria-label="Menu" onClick={() => setMobileOpen(true)} className="rounded p-1 opacity-80 hover:opacity-100 lg:hidden">
              <Menu className="h-4 w-4" />
            </button>
          </div>
        </nav>

        {/* Edu toggle strip */}
        <div className="hidden border-t border-white/10 md:block">
          <div className="mx-auto flex max-w-[1024px] items-center justify-between px-4 py-1.5 text-[11px] text-white/70">
            <span className="flex items-center gap-1.5"><GraduationCap className="h-3.5 w-3.5" /> Education pricing saves ~6% for students & educators</span>
            <label className="flex cursor-pointer items-center gap-2">
              <span>{eduPricing ? "Education ON" : "Education OFF"}</span>
              <button
                role="switch"
                aria-checked={eduPricing}
                onClick={() => setEduPricing(!eduPricing)}
                className={cn("h-5 w-9 rounded-full p-0.5 transition", eduPricing ? "bg-[#0071e3]" : "bg-white/20")}
              >
                <span className={cn("block h-4 w-4 rounded-full bg-white transition-transform", eduPricing && "translate-x-4")} />
              </button>
            </label>
          </div>
        </div>
      </header>

      {/* Mobile drawer */}
      {mobileOpen && (
        <div className="fixed inset-0 z-[70] lg:hidden" role="dialog" aria-modal="true" aria-label="Menu">
          <div className="absolute inset-0 bg-black/50" onClick={() => setMobileOpen(false)} />
          <div className="drawer-enter absolute right-0 top-0 flex h-full w-[86%] max-w-sm flex-col bg-[#161617] text-white">
            <div className="flex items-center justify-between p-5">
              <AppleMark className="h-5 w-4 opacity-90" />
              <button aria-label="Close menu" onClick={() => setMobileOpen(false)} className="rounded-full bg-white/10 p-2"><X className="h-4 w-4" /></button>
            </div>
            <div className="flex-1 overflow-y-auto px-6 pb-8">
              {[{ id: "home", label: "Home" }, ...NAV_ITEMS].map((n) => (
                <button
                  key={n.id}
                  onClick={() => {
                    setMobileOpen(false);
                    if (n.id === "home") go({ name: "home" });
                    else if (n.id === "support") go({ name: "support" });
                    else if (n.id === "entertainment") go({ name: "entertainment" });
                    else if (n.id === "accessories") go({ name: "accessories" });
                    else if (n.id === "store") go({ name: "store" });
                    else go({ name: "category", family: n.id });
                  }}
                  className="flex w-full items-center justify-between border-b border-white/10 py-4 text-left text-[19px] font-semibold"
                >
                  {n.label}<ChevronRight className="h-4 w-4 text-white/40" />
                </button>
              ))}
              <div className="mt-6 space-y-3 text-sm text-white/70">
                <p className="flex items-center gap-2"><MapPin className="h-4 w-4" /> Find a Store — Orchard, MBS, Jewel</p>
                <p className="flex items-center gap-2"><Truck className="h-4 w-4" /> Free delivery across Singapore</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Search overlay */}
      {searchOpen && (
        <div className="fixed inset-0 z-[70]" role="dialog" aria-modal="true" aria-label="Search apple.com">
          <div className="absolute inset-0 bg-black/45 backdrop-blur-sm" onClick={() => setSearchOpen(false)} />
          <div className="search-overlay absolute inset-x-0 top-0 bg-[#161617] pb-8 pt-4 text-white shadow-2xl">
            <div className="mx-auto max-w-[680px] px-5">
              <div className="flex items-center gap-3 border-b border-white/15 pb-3">
                <Search className="h-4 w-4 text-white/60" />
                <input
                  ref={inputRef}
                  value={q}
                  onChange={(e) => setQ(e.target.value)}
                  placeholder="Search apple.com.sg — try “Pro”, “Watch”, “M6”"
                  className="w-full bg-transparent text-[17px] outline-none placeholder:text-white/40"
                  aria-label="Search products"
                />
                <button onClick={() => setSearchOpen(false)} aria-label="Close search" className="rounded-full bg-white/10 p-1.5"><X className="h-4 w-4" /></button>
              </div>
              {q.trim() === "" ? (
                <div className="pt-5">
                  <p className="text-[12px] uppercase tracking-widest text-white/40">Quick links</p>
                  <div className="mt-3 grid grid-cols-1 gap-1 sm:grid-cols-2">
                    {["iPhone 18 Pro", "MacBook Pro M6", "Trade In", "AirPods Pro 3", "Apple Watch Series 12", "Accessories"].map((s) => (
                      <button key={s} onClick={() => setQ(s)} className="flex items-center gap-2 rounded-lg px-3 py-2.5 text-left text-[15px] hover:bg-white/10">
                        <ArrowRight className="h-3.5 w-3.5 text-white/40" /> {s}
                      </button>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="pt-4">
                  {results.length === 0 ? (
                    <p className="py-6 text-center text-white/60">No matches for “{q}”. Try “iPhone”, “Mac” or “Watch”.</p>
                  ) : (
                    <ul className="divide-y divide-white/10">
                      {results.map((p) => (
                        <li key={p.id}>
                          <button
                            onClick={() => go({ name: "product", id: p.id })}
                            className="flex w-full items-center gap-4 py-3 text-left hover:bg-white/5 rounded-lg px-2"
                          >
                            <span className={cn("h-11 w-11 shrink-0 rounded-xl bg-gradient-to-br", p.gradient)} aria-hidden="true" />
                            <span className="flex-1">
                              <span className="block font-semibold">{p.name}</span>
                              <span className="block text-[13px] text-white/55">{p.tagline} — {SGD(p.basePrice)}</span>
                            </span>
                            <ChevronRight className="h-4 w-4 text-white/30" />
                          </button>
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              )}
              <p className="mt-4 text-[12px] text-white/35">Prices include 9% GST · Free delivery · ⌘K to search anywhere</p>
            </div>
          </div>
        </div>
      )}

      {/* Bag drawer */}
      {bagOpen && (
        <div className="fixed inset-0 z-[70]" role="dialog" aria-modal="true" aria-label="Shopping bag">
          <div className="absolute inset-0 bg-black/45" onClick={() => setBagOpen(false)} />
          <aside className="drawer-enter absolute right-0 top-0 flex h-full w-full max-w-md flex-col bg-white shadow-2xl">
            <div className="flex items-center justify-between border-b border-black/10 px-6 py-5">
              <h2 className="text-[21px] font-bold tracking-tight">Your Bag {bagCount > 0 && <span className="text-[#6e6e73] font-medium">({bagCount})</span>}</h2>
              <button onClick={() => setBagOpen(false)} aria-label="Close bag" className="rounded-full bg-black/5 p-2 hover:bg-black/10"><X className="h-4 w-4" /></button>
            </div>
            <div className="flex-1 overflow-y-auto px-6 py-4">
              {bag.length === 0 ? (
                <div className="flex h-full flex-col items-center justify-center text-center">
                  <ShoppingBag className="h-10 w-10 text-[#d2d2d7]" />
                  <p className="mt-4 text-[19px] font-semibold">Your bag is empty.</p>
                  <p className="mt-1 text-sm text-[#6e6e73]">Find something you’ll love — free delivery on everything.</p>
                  <button onClick={() => go({ name: "store" })} className="btn-apple-blue mt-5 px-6 py-2.5 text-[15px]">Shop the Store</button>
                </div>
              ) : (
                <ul className="divide-y divide-black/10">
                  {bag.map((l) => (
                    <li key={l.key} className="flex gap-4 py-4">
                      <div className={cn("h-20 w-20 shrink-0 rounded-2xl bg-gradient-to-br", l.imageGradient)} aria-hidden="true" />
                      <div className="flex-1">
                        <p className="font-semibold leading-tight">{l.name}</p>
                        <p className="text-[13px] text-[#6e6e73]">{l.variant}</p>
                        {l.meta && <p className="text-[12px] text-[#0071e3]">{l.meta}</p>}
                        <div className="mt-2 flex items-center justify-between">
                          <div className="flex items-center gap-2 rounded-full border border-black/10 px-2 py-1">
                            <button aria-label="Decrease" onClick={() => updateQty(l.key, l.qty - 1)} className="p-1"><Minus className="h-3.5 w-3.5" /></button>
                            <span className="min-w-5 text-center text-sm font-semibold">{l.qty}</span>
                            <button aria-label="Increase" onClick={() => updateQty(l.key, l.qty + 1)} className="p-1"><Plus className="h-3.5 w-3.5" /></button>
                          </div>
                          <p className="text-[15px] font-semibold">{SGD(l.unitPrice * l.qty)}</p>
                        </div>
                      </div>
                      <button aria-label={`Remove ${l.name}`} onClick={() => removeLine(l.key)} className="self-start rounded p-1 text-[#6e6e73] hover:text-red-600"><Trash2 className="h-4 w-4" /></button>
                    </li>
                  ))}
                </ul>
              )}
            </div>
            {bag.length > 0 && (
              <div className="border-t border-black/10 bg-[#f5f5f7] px-6 py-5">
                <div className="flex justify-between text-[15px]"><span>Subtotal (incl. GST)</span><span className="font-semibold">{SGD(subtotal)}</span></div>
                <p className="mt-1 text-[12px] text-[#6e6e73]">Free delivery · Free returns · 9% GST included</p>
                <button onClick={() => go({ name: "checkout" })} className="btn-apple-blue mt-4 w-full py-3 text-[16px] font-medium">Check Out with Apple Pickup</button>
                <button onClick={() => go({ name: "store" })} className="mt-2 w-full py-2 text-center text-[14px] text-[#0066cc] hover:underline">Continue shopping</button>
              </div>
            )}
          </aside>
        </div>
      )}
    </>
  );
}

export function ProductThumb({ gradient, size = "md" }: { gradient: string; size?: "sm" | "md" }) {
  return <div aria-hidden="true" className={cn("rounded-2xl bg-gradient-to-br", gradient, size === "sm" ? "h-14 w-14" : "h-20 w-20")} />;
}
